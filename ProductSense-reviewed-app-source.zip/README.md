# ProductSense

Turn small public feedback samples into evidence-linked opportunities and editable product requirements documents.

## Status
The Windows application works locally. Vercel live deployment and persistent PostgreSQL integration are in progress. No public live-AI URL is claimed yet.

## Windows setup
Install Python 3.11, extract or clone this repository, open PowerShell in its folder, and run:

```powershell
py -3.11 launch.py setup
py -3.11 launch.py start
```

Open http://127.0.0.1:8001. The saved demo needs no key. To enable optional Gemini, copy .env.example to .env and configure a verified free-tier key privately. Never commit .env or enable billing for this project.

## Workflow
CSV or historical Excalidraw demo -> editable opportunities -> explicit scope approval/corrections -> PRD -> review/editing/scoped revisions -> version history -> Markdown/Word exports.

Saved templates are labelled and do not represent new AI generation. Gemini requests use bounded calls and no paid fallback. Only public, non-sensitive data is suitable for unpaid Gemini. Historical issues do not prove current missing features. Outputs need product/engineering review before implementation.

## Privacy and publication
Visitor cookies restrict workspace access. Runtime databases, credentials, private research, author drafts and historical archives are excluded from this repository. Keep browser cookies to retain access; export your work. Never upload confidential/customer-identifying information.

## Licence
Project-authored application code is MIT licensed. Third-party dependencies and public feedback retain their respective rights; see NOTICE.md. Research archives/manuscript are maintained separately and are not included in this initial application publication.
