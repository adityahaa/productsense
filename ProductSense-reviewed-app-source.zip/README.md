# ProductSense

## Reviewed application-source update — 10 November 2026

The browser now shows the selected opportunity evidence ledger before approval, without approving or mutating scope. Evidence and review screens expose requirement traceability and review flags; the local research view is available only with `PRODUCTSENSE_RESEARCH_MODE=1` and is blocked in public demo mode. The optional research view code is included, but research datasets, raw issue text, study outputs, private ledgers, drafts, runtime databases and credentials are not in this application-source archive.

The automated ledger/traceability/static checks passed (13 tests), frontend safety/recovery suites passed (12 + 3 assertions), the additional selected app/security/research/paper checks passed (34 passed, 1 skipped because `pdflatex` was unavailable), historical integrity verified (717 checksums), and the manuscript number audit reported 65 matches, 0 mismatches, 9 informational notes. These checks do not establish semantic citation accuracy. See [the local UI update record](docs/LOCAL_UI_UPDATE_2026-11-10.md). ProductSense remains a local application; no ProductSense deployment is claimed.

## Latest source snapshot — 1 November 2026

This complete ZIP includes research, saved evaluation results, scripts and frozen records. The local application is verified; optional cloud_store.py/cloud_jobs.py are unfinished PostgreSQL scaffolding and are not enabled by ordinary Windows startup. Public CDN assets are prepared. Vercel live deployment is not complete. The GitHub repository currently contains a separate application-only archive. Credentials, private runtime/databases, author drafts and reveal mappings are withheld. Historical archives with privacy redactions are explicitly named public-redacted; exact private originals remain preserved locally.


## Final local release — 27 October 2026

Run `py -3.11 launch.py setup` once after extracting, then `py -3.11 launch.py start`. Open **http://127.0.0.1:8001**. Existing installation: `.\.venv\Scripts\python.exe launch.py start`. Python 3.11 was tested; 3.12 is supported but a clean 3.12 installation was not tested. Setup preserves `.env` and runtime. No key is required for the saved demo.

The application now enforces visitor ownership, controlled JSON errors, body limits, creation/write rate limits, capacity and workspace expiry. Public saved-demo mode hides CSV/live controls and forcibly disables live credentials. See [final verified results](docs/FINAL_RESULTS.md) and [release/deployment readiness](docs/RELEASE_READINESS.md). Browser cookies identify the owner; losing a cookie does not grant another browser access. Earlier unowned workspaces remain on disk and are not automatically claimable.

Research generation is complete: **28 evaluation PRDs, 4 development outputs, 8 terminal reservation failures, zero pending slots**. Generation used 87 attempts and 239,303 known tokens; retrospective AI assessment used 20 calls and 62,237 tokens. Total **107/180 attempts**, with one historical generation failure whose usage is unknown. All 28 PRDs were assessed through 18 distinct text/input packets; strict validation permits semantic aggregation for only 18/28 slots. No human ratings were completed, and the private author draft remains unsubmitted. Human review is optional, not a delivery dependency. Do not restart the completed generation schedule or rescore invalid assessments.

Read the complete exploratory manuscript in [Markdown](research/final_paper/ProductSense_Manuscript.md), [Word](research/final_paper/ProductSense_Manuscript.docx), or [PDF](research/final_paper/ProductSense_Manuscript.pdf). [AI assessment protocol](research/ai_evaluation_v1/PROTOCOL.md), raw outputs and [results](research/ai_evaluation_v1/reports/summary.json) are included. Reproduce current offline tables/figures with `python -m evaluation.ai_report`; no API calls or private database are needed. The small, selective same-model assessment does not establish agent superiority or a worthwhile return on added inference.

Dated sections below preserve historical milestones; their pending-rating/provider-paused instructions are superseded by this release. Nothing has been deployed, published or submitted.

Turn a small feedback CSV or the built-in public Excalidraw sample into evidence-linked opportunities and a full editable PRD. Runs locally on Windows, with no accounts and no frontend build tools. The saved demo costs ₹0 and requires no API key. Live generation uses only the Gemini Developer API; there is no paid fallback.

Real Gemini activation is now verified: six bounded generations, approved scope, correction probe, review, exports and a same-input baseline. See [actual results and limitations](docs/LIVE_RESULTS.md). The saved demo remains separate and unchanged; the comparison does not establish agent superiority.

Deferred browser verification is now complete: demo/CSV, approval with corrections, real generation/review, editing/saving and Markdown/Word downloads. The new run used four successful calls; its raw AI output and subsequent assistant edits are preserved separately. All four pages of the edited Word export were visually inspected. See [browser verification](docs/BROWSER_VERIFICATION.md), [saved-output comparison](docs/QUALITY_COMPARISON.md), and [prepared free deployment](docs/DEPLOYMENT_READY.md). No further generation is needed to inspect these results; nothing has been published.

## Combined study and author review — 25 October 2026

The [current checkpoint](docs/COMBINED_STUDY_STATUS.md) and [review instructions](research/study_v2/README.md) describe the preserved study and new local author-review interface. Open http://127.0.0.1:8010 for your own ratings, with generation condition/usage masked until all planned ratings lock. This is author-conducted single-reviewer human evaluation; no independent validation is claimed.

The phase has36attempts and94680known reported tokens,13finaloutputs (4development+9evaluation),4terminalreservation failures and23pendingevaluation slots. One provider/network request failed with unknown token usage; live calls stopped. Research-only localdailycap was removed after explicit chat confirmation, while cumulative180, ordinary-app protections and actual provider restrictions remain. Your private runtime ledger and review database are retained locally and excluded from the source ZIP. No actual human ratings have been supplied yet.

The ordinary offline application and saved examples remain separate. See the research README for the exact author-review launch, export/analysis and legitimate provider-resume commands. Original pilots/freezes/source/amendments are preserved; no successful output is regenerated.

## Reliability and research upgrade — 24 October 2026

Read [upgrade results and limitations](docs/UPGRADE_RESULTS.md). Analysis now supports row moves, split/merge, editable scope and Build/Investigate/Defer recommendations. Saving records an audit and requires approval again; existing PRDs stay available with a review warning. Evidence cards distinguish supplied quotes from semantic judgement and rows from identified customers.

In the editor, use **Scoped revision & version history** to request a section change. Offline mode requires explicit replacement text; Gemini mode uses at most one call. Inspect the plan, approve affected scope, then inspect the version diff. Select manual/assistant attribution honestly. The export appendix adds acceptance links and unresolved warnings. Whole-editor scope changes also require the renewed-approval checkbox.

Research files: [protocol](research/PROTOCOL.md), [rubric](research/RUBRIC.md), [related work](research/RELATED_WORK.md), and `research/results/`. The executed one-case pilot is complete; do not repeat its calls. `research/frozen/run-source.zip` preserves its exact source. The app checker was repaired afterwards, so the old manifest intentionally rejects the modified app. Prepare a new versioned protocol before future experiments. Matched-budget and ablation conditions are implemented but unexecuted. Human scores remain blank.

Offline checks: `.\.venv\Scripts\python.exe -m pytest -q`. No key is needed for regression tests. On a fresh extracted ZIP, replace the path below with the location where you extracted the `productsense` folder. Keep your existing private `.env` and runtime folder when updating an installed copy; neither is distributed in the source ZIP.

## First run on Windows

Install **Python 3.11 or 3.12** from [python.org](https://www.python.org/downloads/windows/) if it is not installed. Check “Add python.exe to PATH” in the installer. Open **PowerShell**, then paste these commands one at a time:

```powershell
cd 'C:\path\to\ProductSense'
py -3.11 launch.py setup
py -3.11 launch.py start
```

If Python 3.12 is installed instead, use `py -3.12 launch.py setup` and `py -3.12 launch.py start`. If `py` is unavailable but `python --version` reports 3.11+, use `python -m venv .venv`. You do not need to activate the virtual environment, change PowerShell execution policy, install Node, or create a Gemini key for the demo.

`requirements.lock.txt` pins the versions used in the executed checks. `requirements.txt` records the broader compatible dependency ranges for future development.

Open [ProductSense locally](http://127.0.0.1:8001). Keep the PowerShell window running. Press **Ctrl+C** there to stop the server. For later runs, repeat the `cd` and `launch.py start` command. `start.ps1` is an optional shortcut if your PowerShell policy already permits local scripts.

If the port is busy, run `py -3.11 launch.py start --port 8002` and open [port 8002](http://127.0.0.1:8002). If downloads fail, check your Internet connection and rerun the pip command; completed packages are cached. Installations can take several minutes on a slow connection.

## Try the complete demo

1. In **Feedback Explorer**, click **Load public demo**. The 12 rows are short paraphrases of real public Excalidraw GitHub issues, each with its original link. These are historical reports, some potentially resolved.
2. Add a product goal, deadline/planning window and team capacity. Unknown values are allowed and remain unknown. Keep **Saved sample / local template** mode selected. Click **Analyze feedback**.
3. In **Opportunity Prioritisation**, compare groups, sample scores, evidence and assumptions. Choose an opportunity, correct assumptions or narrow scope, tick the explicit approval checkbox, and click **Approve & write PRD**.
4. In **PRD Editor**, use **Edit Markdown**, then **Save & check**. Switch to Preview or download Markdown and Word. Exports include the most recently saved edits; the UI saves pending edits before export.
5. In **Evidence & Review**, follow the original links, inspect warnings and download a workspace JSON backup.

The PRD includes problem statement, target users, goals/non-goals, proposed success metrics, R-numbered requirements, user stories, Given/When/Then acceptance criteria, edge cases, non-functional requirements, dependencies, risks, assumptions, open questions and MVP scope.

Demo grouping is saved/editorial for the public sample, keyword-based for uploaded CSVs. The offline PRD is an explicit local template, not a Gemini response. Corrections are preserved as human constraints; reconcile them with the template by editing the PRD. Live Gemini uses corrections in writing and review. `data/saved_sample_prd.md` and `data/saved_sample_output.json` are labelled examples once generated by the verification script.

## Upload a CSV

Use UTF-8, up to **30 rows**, **100,000 bytes**, and **1,200 characters per feedback text**. Required column: `text`. Optional columns: `id`, `source_url`, `source_date` (YYYY-MM-DD), `source_status`, `customer_id` (public pseudonymous identifier only), `source_quote` (exact substring of `text`). Other columns are ignored. Missing metadata stays unknown. Never include private identifiers or private feedback in Gemini mode. The public sample is also available as `data/demo_feedback.csv`.

```csv
id,text,source_url
FB-1,"The exported drawing loses its text formatting.",https://example.com/feedback/1
FB-2,"I cannot tell whether a sharing link allows editing.",
```

The URLs above illustrate the upload format and are not demo evidence. IDs must be unique and contain letters, digits, underscores or hyphens. Exact text duplicates (ignoring case and whitespace), empty rows, malformed quoting, unsafe links, duplicate headers and excessive sizes are rejected rather than silently dropped. Missing links remain labelled uploaded evidence without an external source. An accepted HTTP URL is not independently verified. Source URLs are never fetched by the backend.

Feedback, context, prior drafts and corrections are untrusted data. The model has no filesystem, browsing, code execution or other tool access. Uploaded text cannot grant it permissions. Safe rendering escapes HTML and accepts only HTTP(S) external links; prompt injection cannot be guaranteed impossible, so human review remains necessary.

## Optional Gemini FREE TIER setup

Official documentation was checked **21 October 2026**. The default `gemini-3.5-flash-lite` has free Standard text input/output in the [official pricing table](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.5-flash-lite). Account eligibility and quota still need your own verification. See [provider, data-use and deployment details](docs/PROVIDER_AND_DEPLOYMENT.md) for all official references.

1. Open [Google AI Studio API keys](https://aistudio.google.com/apikey) and create a key for a **Free Tier project with no billing account attached**. Do not add billing, credits or a payment method.
2. Check that exact project in [AI Studio Projects](https://aistudio.google.com/projects), then check its [active rate limits](https://aistudio.google.com/usage?timeRange=last-28-days&tab=rate-limit). A visible model alone does not prove free billing or available quota.
3. In the app folder, create the private file once:

   ```powershell
   if (-not (Test-Path -LiteralPath '.env')) { Copy-Item -LiteralPath '.env.example' -Destination '.env' }
   notepad .env
   ```

4. In Notepad, save your key as `GEMINI_API_KEY=your_key_here`. Keep `GEMINI_MODEL=gemini-3.5-flash-lite`. After checking the free project, set `GEMINI_FREE_TIER_CONFIRMED=true`. After reading the data-use terms and deciding to use only public/non-sensitive input, set `GEMINI_PUBLIC_DATA_CONFIRMED=true`.
5. Restart the server, optionally run the metadata-only check below, then start a **new workspace** and select Gemini mode.

   ```powershell
   .\.venv\Scripts\python.exe scripts/check_gemini.py
   ```

Never send your key in chat. `.env` is ignored by Git/Docker and served by neither the frontend nor static file route. No key is returned from `/api/config`. The app does not print raw provider exceptions or request contents. If a key leaks, revoke it in AI Studio.

**₹0 boundary:** the app cannot inspect or override Google's project billing status. The confirmation is your attestation; a key from a billed project can incur costs even when the same model has a free tier. Keep the project unbilled. Only the checked allowlist in `app/config.py` is accepted; an unavailable or unlisted model stops the run. There is no model/provider fallback, billing operation, Google Search, paid embeddings or hosted database.

**Data use:** unpaid Gemini inputs and generated outputs may be used for product improvement and human review. Send only public, non-sensitive data; the live-mode warning also applies to product context and corrections. Regional terms differ; see the [official terms](https://ai.google.dev/gemini-api/terms). Local demo mode sends nothing to Google.

## Limits, caching and resume

- Local grouping and selected-evidence retrieval use lexical matching; no embeddings. The PRD writer sees evidence from the approved group only.
- Caps: 6 generation attempts per workspace, 20 per UTC day across this local database, 60,000 input characters per model step, 6,000 output tokens and 40,000 editable PRD characters. These are app safety caps, not Google's quotas. Failed attempts count.
- Normal live path: analysis, writing, model review; optional one revision. The final check after revision is deterministic. Prioritisation is a transparent local formula: `70 × sample share + 30 × fraction of goal keywords present`. It estimates neither effort nor business value.
- Local cache keys include the model, task, system policy, JSON schema and exact input. Cache hits are recorded as agent events and do not consume generation calls.
- A 429, outage or invalid response pauses the graph with an actionable message. No automatic retries. Resume later continues the checkpoint and reuses completed work. A run that exhausts its total call cap cannot make more calls; export its progress and finish manually or start a smaller sample.
- Google daily quotas reset on Pacific time; the app's separate daily safety counter resets at midnight UTC. Check your actual project limits in AI Studio.
- `runtime/productsense.sqlite` stores sessions, cache and attempted-call counters; `runtime/checkpoints.sqlite` stores LangGraph state. Keep **both** files to resume after restarting. Stop the server before copying the entire `runtime/` folder for a consistent backup. Files contain feedback/drafts; treat them as private. They do not store your API key.
- The browser remembers the current session ID and recovers unsaved Markdown drafts using localStorage. Server checkpoints survive browser refresh. A downloaded JSON backup is for inspection/export, not a substitute for the graph database; JSON import is not implemented.

## Tests and evaluation

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m evaluation.run
node --check static/app.js
```

Node is optional and only used for the JavaScript syntax check by developers. The app itself needs Python only. Tests use temporary databases and mocked provider responses; they do not use a real key or billable API. See `docs/VERIFICATION.md` for executed results and verification limits.

The offline evaluation executes the LangGraph template workflow and measures it alongside an explicitly hand-authored single-prompt-style fixture using the same approved scope/input. It checks structure, reference IDs, links, requirement labels and numeric claims. **This is not an empirical comparison of model quality.** No AI baseline result is claimed without a real API execution.

For real free-tier activation and an actual same-model comparison, follow [the staged live guide](docs/LIVE_ACTIVATION.md). Start with a secret-safe readiness check:

```powershell
.\.venv\Scripts\python.exe -m evaluation.live status
```

The live protocol preserves the approval interrupt, uses a six-row public source pack and shares one six-attempt budget across workflow, baseline and an optional uncorrected control. Both PRD writers receive the same selected evidence, context, scope and corrections. Usage records distinguish new attempts, cached replays and provider-reported tokens. The workflow's server-appended source register is excluded from model citation scoring. Results go to ignored `evaluation/live-results/`. One small pair cannot establish superiority; inspect evidence support and unsupported factual claims as well as completeness. The earlier `evaluation.run --live` command now shows readiness only and never auto-approves a scope. Real execution status is recorded in `HANDOFF.md` and the verification report.

## Architecture and files

```text
app/main.py       FastAPI routes, validation, same-origin mutations, static UI
app/workflow.py   Typed shared state, LangGraph nodes, SQLite approval interrupt
app/provider.py   Only Gemini generation path, caps, schema validation, local cache
app/store.py      Session/cache/counter persistence
app/feedback.py   CSV and URL validation
app/prd.py        Offline PRD, structural review, Word export with clickable links
static/           Four screens, accessible controls, safe preview, no build step
data/             Real public issue sample and labelled saved outputs
tests/            Validation, approval, export, restart, quota/cache/provider tests
evaluation/       Reproducible offline fixture and optional live comparison
HANDOFF.md        Completed stages, checks, issues and next action
```

LangGraph flow: `analyze → prioritize → approval interrupt → write → review → [one revision → structural recheck] → complete`. `Command(resume=...)` supplies the explicit user decision to the checkpoint. A model cannot approve its own opportunity.

Requirements have evidence references or Proposal/Assumption labels. The review percentage measures requirements with either traceability or a label, **not evidence truth or customer coverage**. Automated review cannot prove evidence entailment, current relevance, scope feasibility or business impact. Generated and edited PRDs require human judgement before implementation. Word export supports headings, paragraphs, bullets and HTTP links; advanced Markdown tables/code formatting are preserved as readable text, not rich layouts.

## Optional free deployment — documented only

Local execution is the supported personal-use setup. No external publication has been performed.

An optional **Render Free web service** can host a saved-sample demo. Current limits and official sources are in [the deployment notes](docs/PROVIDER_AND_DEPLOYMENT.md). Free services sleep after 15 idle minutes, have a shared 750-hour monthly allowance and **no persistent disk**. Local sessions/checkpoints disappear on restart/redeploy/spin-down. Use a no-payment-method Free account; if payment verification is required, stop. A card-linked account can incur overages.

After you explicitly choose to publish: put this source in a repository excluding `.env`, `.venv` and `runtime`; create a Render Python web service on the **Free** instance; build with `pip install -r requirements.lock.txt`; start with `uvicorn app.main:app --host 0.0.0.0 --port $PORT --no-access-log`. Set Python to a supported 3.11+ version. Leave Gemini key/confirmation variables unset so the public demo cannot spend your quota. Use `/api/health` for the health check. `Dockerfile` is also supplied if you choose a free Docker service later.

This app has no accounts or access control: anyone with a session URL on a public deployment can read/change that workspace. Do not upload private feedback there. Public live mode requires additional abuse controls, persistence, account verification and regional-policy review; it is outside this local ₹0 release. Render setup has been researched but not deployed or tested here. New Hugging Face compute Spaces currently require a paid plan and are unsuitable for this budget.

## Resume this build

If interrupted, type **continue** in this chat. The agent should read `HANDOFF.md`, retain completed work, and continue the recorded next action. Do not recreate the app or delete runtime progress.

### Conversational research review
The separate local review interface now asks one question at a time, preserving saved draft answers. It works without any API calls. Start with `.\.venv\Scripts\python.exe -m uvicorn evaluation.author_review:create_app --factory --host 127.0.0.1 --port 8010 --no-access-log`, then open http://127.0.0.1:8010. Answer honestly about earlier ChatGPT assistance; review and explicitly confirm the summary before submission. See research/study_v2/CONVERSATIONAL_REVIEW_PROTOCOL.md. The ordinary application is unchanged.


## Research infrastructure added in the v3 improvement pass (2026-11-01)
Start here: `IMPROVEMENT_BASELINE.md` (initial state), `SCIENTIFIC_IMPROVEMENT_REPORT.md` (what changed and what did not), `VERIFICATION.md` (executed checks and failures), `NEXT_STEPS.md`.

**New application features:** a Traceability screen (requirement-to-evidence matrix, evidence ledger, version comparison, CSV export), the routes `/api/sessions/{id}/traceability`, `/traceability.csv`, `/evidence-ledger`, `/versions/compare`, and an opt-in local research view (`PRODUCTSENSE_RESEARCH_MODE=1`, never in public-demo mode). Flags are candidates for human inspection; no accuracy percentage is computed.

**Research study_v3 (planned, not executed):** `research/study_v3/` holds a 22-case product-disjoint dataset with provenance, an offline validator, a draft protocol, a mock-tested arm runner with actual-token budgeting, a counterbalanced planner, an analysis pipeline, a blinded human-review package builder and annotation guide. **No live study has been run and no new quality result exists.** Historical study_v2 files are unchanged.

**One command each (after `pip install -r requirements-research.txt`):**
- Application and research regression suite: `python -m pytest -q` (expect 1 environment-only failure, `test_launcher_check_and_unsupported_port`, unless the project-local `.venv` exists), plus `node tests/frontend_safety.cjs tests/frontend_recovery.cjs tests/frontend_trace.cjs` run one at a time.
- Offline research verification: `python research/study_v3/verify_historical.py && python research/study_v3/validate_dataset.py && python -m evaluation.ai_report` (run the last one in a scratch copy: it rewrites `research/ai_evaluation_v1/reports`).
- Dry run of the planned live study: `python research/study_v3/plan.py`; `python research/study_v3/runner.py --stage dev --max-calls 42 --dry-run`. Live runs need your own free-tier Gemini key with `GEMINI_FREE_TIER_CONFIRMED=true` and `GEMINI_PUBLIC_DATA_CONFIRMED=true`, are free-tier only, and stop on any quota error.

**Seeded-defect validation (offline, new result):** `python research/study_v3/seeded_defect_study.py` injects known defects into 18 real historical PRDs and measures what the deterministic checks detect. Pattern defects are caught (largely by construction); semantic defects (wrong-but-valid citation, negated requirement) are not. See `SCIENTIFIC_IMPROVEMENT_REPORT.md` section 3b and `PAPER_CLAIMS_GUIDE.md` for what a paper can and cannot claim.

**Also offline:** `python research/study_v3/power_simulation.py` (design-level power analysis; assumption-driven), `python research/study_v3/run_index.py update` (refresh the run index from files on disk). The assessment runner is `research/study_v3/assess.py` (see `ASSESSMENT_PROTOCOL.md`).

**Manuscript:** `research/study_v3/paper/` (IEEE conference format, `pdflatex main.tex` twice; see its README), `PAPER_REVISION_NOTES.md` (audit findings and what only the authors can do) and `PAPER_CLAIMS_GUIDE.md` (what can and cannot be claimed). `python research/study_v3/audit_manuscript_numbers.py` recomputes the paper's numbers from the raw records.

**Working on this project with a coding agent (Codex etc.):** read `AGENTS.md` (rules, map, commands, tunable parameters) and paste `CODEX_PROMPT.md`. `python scripts/frontend_sync_audit.py` shows which backend routes the UI calls; `python scripts/build_static.py` regenerates `public/` from `static/`.
