'use strict';
// Traceability screen. Counts and candidate flags only: no accuracy percentage. Every dynamic string goes through esc().
let traceData=null, traceLedger=null, traceCompare=null, traceKey='', traceLoading=false, traceError='';

async function loadTrace(key){
  traceLoading=true; traceError='';
  try{
    const base='/api/sessions/'+session.id;
    traceData=await api(base+'/traceability');
    traceLedger=await api(base+'/evidence-ledger').catch(()=>null);
    traceCompare=await api(base+'/versions/compare').catch(()=>null);
    traceKey=key;
  }catch(e){traceError=String(e&&e.message||e); traceData=null; traceKey=key;}
  traceLoading=false; render();
}

const SEV={error:'error',warning:'warning',info:'info'};
function flagList(flags){
  return flags.length?'<ul class="trace-flags">'+flags.map(f=>`<li class="trace-${esc(SEV[f.severity]||'info')}" title="${esc(f.message)}"><strong>${esc(f.code)}</strong> &mdash; ${esc(f.message)}</li>`).join('')+'</ul>':'<span class="tiny muted">No flags</span>';
}
function evidenceLinks(list){
  return list.length?list.map(c=>c.known?`<a href="#evidence/${esc(encodeURIComponent(c.id))}">${esc(c.id)}</a>`:`<span class="trace-error" title="Not in supplied feedback">${esc(c.id)}?</span>`).join(', '):'<span class="tiny muted">none</span>';
}
function ledgerCard(L){
  if(!L)return '';
  const li=a=>a.length?'<ul>'+a.map(x=>`<li>${esc(x)}</li>`).join('')+'</ul>':'<p class="tiny muted">None.</p>';
  const pairs=a=>a.length?'<ul>'+a.map(p=>`<li>${esc(p.ids.join(' & '))}: ${esc(p.reason)}</li>`).join('')+'</ul>':'<p class="tiny muted">None.</p>';
  return `<section class="card"><div class="card-header"><div><h2>Evidence ledger (before drafting)</h2><p>Observed reports are kept apart from your constraints and from proposals. Candidates are hints, not conclusions.</p></div></div>
  <h3>Reported feedback</h3>${li((L.observed_reports||[]).map(r=>r.id+' — '+r.source_status+'; '+r.note))}<h3>User constraints</h3>${li(Object.entries(L.user_constraints||{}).filter(([k,v])=>v&&k!=='note').map(([k,v])=>k+': '+v))}<p class="tiny muted">${esc(L.proposals_note||'')}</p><h3>Open questions</h3>${li(L.open_questions)}<h3>Warnings</h3>${li(L.warnings.map(w=>w.message))}
  <h3>Duplicate candidates</h3>${pairs(L.duplicate_candidates)}<h3>Conflict candidates</h3>${pairs(L.conflict_candidates)}</section>`;
}
function compareCard(C){
  if(!C||C.available===false)return `<section class="card"><div class="card-header"><div><h2>Version comparison</h2></div></div><p class="tiny muted">At least two saved versions are needed. Edit or revise the PRD to create another.</p></section>`;
  const ids=a=>a.length?a.map(esc).join(', '):'none';
  const changed=C.changed.map(c=>`<li><strong>${esc(c.id)}</strong>${c.text_changed?' text changed':''}${c.evidence_added.length?'; evidence added: '+ids(c.evidence_added):''}${c.evidence_removed.length?'; evidence removed: '+ids(c.evidence_removed):''}${c.acceptance_added.length||c.acceptance_removed.length?'; acceptance links changed':''}${c.new_flags.length?'; new flags: '+ids(c.new_flags):''}</li>`).join('');
  return `<section class="card"><div class="card-header"><div><h2>Version comparison</h2><p>Version ${esc(C.from.id)} (${esc(C.from.origin)}) to ${esc(C.to.id)} (${esc(C.to.origin)}). Scope changes need renewed approval.</p></div></div>
  <p>Added: ${ids(C.added)} &middot; Removed: ${ids(C.removed)} &middot; Unchanged: ${C.unchanged.length}</p>${C.possible_renumbering.length?'<p>Possible renumbering: '+C.possible_renumbering.map(r=>esc(r.from)+' &rarr; '+esc(r.to)).join(', ')+'</p>':''}
  ${changed?'<ul>'+changed+'</ul>':'<p class="tiny muted">No requirement-level changes.</p>'}</section>`;
}
function traceScreen(){
  let html=intro('05 / Traceability','See what each requirement rests on.','Requirement-to-evidence matrix with candidate flags. A cited ID or shared vocabulary does not prove the source supports the requirement.')+workflow()+banners();
  if(!session)return html+empty('Start with a feedback sample','The matrix appears after a PRD exists.');
  if(!session.prd_markdown)return html+empty('Generate a PRD first','Approve an opportunity to create requirements to trace.');
  const key=session.id+':'+session.prd_markdown.length+':'+(session.prd_markdown.slice(-40));
  if(traceKey!==key&&!traceLoading)loadTrace(key);
  if(traceLoading||traceKey!==key)return html+empty('Loading traceability','Reading the saved PRD and evidence.');
  if(traceError||!traceData)return html+empty('Traceability unavailable',esc(traceError||'No data.'))+'<button type="button" id="retry-trace">Retry traceability</button>';
  const m=traceData, s=m.summary;
  const rows=m.requirements.map(r=>`<tr><td><strong>${esc(r.id)}</strong></td><td>${esc(r.text)}</td><td><span class="pill neutral">${esc(r.provenance)}</span>${r.provenance_labels.length?'<br><small>'+r.provenance_labels.map(esc).join(', ')+'</small>':''}</td><td>${evidenceLinks(r.evidence)}</td><td>${r.acceptance.length?r.acceptance.map(a=>esc(a.id)+(a.given_when_then?'':' (no GWT)')).join(', '):'<span class="trace-error">none</span>'}</td><td>${flagList(r.flags)}</td></tr>`).join('');
  return html+`<section class="card"><div class="card-header"><div><h2>Requirement-to-evidence matrix</h2><p>${esc(s.notice)}</p></div><a class="btn btn-secondary" href="/api/sessions/${esc(session.id)}/traceability.csv">&darr; CSV</a></div>
  <div class="review-metrics"><div class="review-metric"><strong>${s.with_valid_evidence_id} of ${s.requirements}</strong><span>cite a supplied evidence ID</span></div><div class="review-metric"><strong>${s.labelled_proposal_assumption_or_constraint_only}</strong><span>labelled only (proposal/assumption/constraint)</span></div><div class="review-metric"><strong>${s.without_provenance}</strong><span>without provenance</span></div><div class="review-metric"><strong>${s.without_linked_acceptance}</strong><span>without linked acceptance</span></div></div>
  <div class="trace-scroll"><table class="trace-table"><thead><tr><th>ID</th><th>Requirement</th><th>Provenance</th><th>Evidence</th><th>Acceptance</th><th>Flags</th></tr></thead><tbody>${rows||'<tr><td colspan="6">No numbered requirements found.</td></tr>'}</tbody></table></div>
  ${m.evidence_not_cited_by_any_requirement.length?'<p class="tiny muted">Evidence not cited by any requirement: '+m.evidence_not_cited_by_any_requirement.map(esc).join(', ')+'</p>':''}</section>${ledgerCard(traceLedger)}${compareCard(traceCompare)}`;
}

// Pre-approval preview reads the currently selected opportunity without recording approval.
let previewKey='', previewLedger=null, previewError='', previewPending=false;
function renderLedgerPreview(current){
 if(!session||!['opportunities','evidence'].includes(current))return;
 const id=selected||session.selected_opportunity_id;
 if(!id)return;
 const key=session.id+':'+id+':'+(session.analysis_revision||0);
 const host=document.createElement('section');host.className='card';
 host.innerHTML='<div class="card-header"><h2>Evidence before scope approval</h2></div><div id="ledger-preview-body" class="card-body" aria-live="polite"></div>';
 document.querySelector('#main').appendChild(host);
 const body=host.querySelector('#ledger-preview-body');
 if(previewKey===key&&!previewPending){body.innerHTML=previewError?'<p role="alert">'+esc(previewError)+'</p><button type="button" id="retry-ledger">Retry evidence ledger</button>':ledgerCard(previewLedger);
 const retry=host.querySelector('#retry-ledger');if(retry)retry.onclick=()=>{previewKey='';render();};return;}
 body.textContent='Loading selected evidence and scope constraints…';
 if(previewPending)return;
 previewPending=true;
 api('/api/sessions/'+session.id+'/evidence-ledger?opportunity_id='+encodeURIComponent(id)).then(data=>{previewLedger=data;previewError='';}).catch(e=>{previewError=e.message;}).finally(()=>{previewKey=key;previewPending=false;render();});
}

function researchPanel(){
 if(!config.research_mode||config.public_demo)return;
 const panel=document.createElement('section');panel.className='card';
 panel.innerHTML='<div class="card-body"><h2>Local research / dataset</h2><p>Researcher-authored scope; historical source reports. New v3 live comparison has not run.</p><button type="button" id="load-local-research">Load dataset and saved runs</button><div id="local-research-result" aria-live="polite"></div></div>';
 document.querySelector('#main').appendChild(panel);
 panel.querySelector('button').onclick=async()=>{
 const button=panel.querySelector('button'),out=panel.querySelector('#local-research-result');button.disabled=true;out.textContent='Loading local research records…';
 try{const [dataset,runs]=await Promise.all([api('/api/research/dataset'),api('/api/research/runs')]);out.innerHTML='<p>'+esc(dataset.notice)+'</p><ul>'+dataset.cases.map(c=>'<li>'+esc(c.product)+' — '+esc(c.id)+' ('+esc(c.split)+'): '+esc(c.opportunity)+'</li>').join('')+'</ul><h3>Saved v3 runs</h3>'+((runs.runs||[]).length?'<ul>'+runs.runs.map(r=>'<li>'+esc(r.id)+' — '+esc(r.status)+' <button type="button" data-local-prd="'+esc(r.id)+'">Read saved PRD</button></li>').join('')+'</ul>':'<p>No saved live v3 runs.</p>');
 out.querySelectorAll('[data-local-prd]').forEach(b=>{b.onclick=async()=>{try{const r=await api('/api/research/runs/'+encodeURIComponent(b.dataset.localPrd)+'/prd');const pre=document.createElement('pre');pre.textContent=r.markdown;out.appendChild(pre);}catch(e){out.appendChild(document.createTextNode(e.message));}};});
 }catch(e){out.textContent=e.message+' Use the button to retry.';}finally{button.disabled=false;}
 };
}

document.addEventListener('click',e=>{if(e.target.id==='retry-trace'){traceKey='';traceError='';render();}});
