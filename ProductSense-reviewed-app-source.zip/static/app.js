'use strict';
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const safeUrl = s => { try { const u = new URL(s); return ['http:','https:'].includes(u.protocol) && !u.username && !u.password ? u.href : ''; } catch { return ''; } };
const screens = [['feedback','Feedback Explorer','▤'],['opportunities','Opportunity Prioritisation','◈'],['editor','PRD Editor','▧'],['evidence','Evidence & Review','◎'],['traceability','Traceability','⇄']];
let session = null, config = {}, selected = '', view = 'preview', dirty = false, draft = '', busy = false, polling = false;
let ctx = {product:'Excalidraw',goals:'Make sharing diagrams outside the editor more reliable.',deadline:'Not set — agree with the team',capacity:'Not estimated — validate with engineering'};
let mode = 'demo', corrections = '', acknowledged = false, query = '';
const storage = {get:k=>{try{return localStorage.getItem(k)}catch{return null}},set:(k,v)=>{try{localStorage.setItem(k,v)}catch{}},remove:k=>{try{localStorage.removeItem(k)}catch{}}};
function toast(message, error=false) { const el=$('#toast'); el.textContent=message; el.className=error?'toast-error':''; el.hidden=false; clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.hidden=true,5500); }
async function api(path, options={}) {
  const response = await fetch(path, {...options, headers: options.body instanceof FormData ? {} : {'Content-Type':'application/json',...(options.headers||{})}});
  if (!response.ok) { const body=await response.json().catch(()=>({})); throw new Error(typeof body.detail==='string'?body.detail:`Request failed (${response.status}). Check the inputs and retry.`); }
  return response.json();
}
function route() { const id=location.hash.slice(1).split('/')[0]; return screens.some(s=>s[0]===id)?id:'feedback'; }
function useSession(data) { session=data; storage.set('productsense-session',data.id); ctx=data.context; mode=data.mode; if(!dirty) draft=data.prd_markdown||''; if(!selected||!data.opportunities.some(o=>o.id===selected)) selected=data.selected_opportunity_id||data.opportunities[0]?.id||''; }
function inline(text) {
  // Tokenize links BEFORE escaping, then escape every text fragment and validate each href.
  return String(text).split(/(\[[^\]]+\]\([^)]+\)|\[[A-Za-z0-9_-]+(?:\s*[,;]\s*[A-Za-z0-9_-]+)*\])/g).map(part=>{
    let m=part.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if(m) { const url=safeUrl(m[2]); return url?`<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(m[1])} ↗</a>`:esc(part); }
    m=part.match(/^\[([A-Za-z0-9_-]+(?:\s*[,;]\s*[A-Za-z0-9_-]+)*)\]$/);
    if(m) {
      const ids=m[1].split(/\s*[,;]\s*/);
      if(ids.some(id=>session?.feedback.some(r=>r.id===id))) return '['+ids.map(id=>session?.feedback.some(r=>r.id===id)?`<a href="#evidence/${esc(id)}">${esc(id)}</a>`:esc(id)).join(', ')+']';
    }
    return esc(part);
  }).join('');
}
function markdown(text) {
  let list=false, html='';
  for(const line of text.split('\n')) {
    const heading=line.match(/^(#{1,4})\s+(.*)/), bullet=line.match(/^[-*]\s+(.*)/);
    if(!bullet&&list){html+='</ul>';list=false;}
    if(heading)html+=`<h${heading[1].length} id="section-${slug(heading[2])}">${inline(heading[2])}</h${heading[1].length}>`;
    else if(bullet){if(!list){html+='<ul>';list=true;}html+=`<li>${inline(bullet[1])}</li>`;}
    else if(line.startsWith('> '))html+=`<blockquote>${inline(line.slice(2))}</blockquote>`;
    else if(line.trim())html+=`<p>${inline(line)}</p>`;
  }
  return html+(list?'</ul>':'');
}
function slug(s){return s.toLowerCase().replace(/[^a-z0-9]+/g,'-').slice(0,100);}
function intro(label,title,description) { return `<div class="page-intro"><div><div class="eyebrow">${esc(label)}</div><h1>${esc(title)}</h1><p class="page-subtitle">${esc(description)}</p></div><div class="intro-aside"><span class="pill">₹0 · no paid fallback</span></div></div>`; }
function workflow() {
  let active=!session||session.status==='new'?0:session.status==='awaiting_approval'?1:session.selected_opportunity_id?2:1;
  if(session?.status==='complete')active=3;
  return `<div class="workflow" aria-label="Workflow progress">${[['Collect feedback','Start with a small sample'],['Choose an opportunity','Your approval matters'],['Write the PRD','Grounded and editable'],['Review & refine','Check every assumption']].map((s,i)=>`<div class="workflow-step ${i<active?'done':i===active?'current':''}"><span class="step-number">${i<active?'✓':i+1}</span><div><strong>${s[0]}</strong><small>${s[1]}</small></div></div>`).join('')}</div>`;
}
function banners() {
  let html=`<div class="info-strip ${mode==='demo'?'':'teal'}"><span aria-hidden="true">ⓘ</span><div><strong>${mode==='demo'?'Saved sample / local template · no AI call':'Gemini live · free project required'}</strong><br>${mode==='demo'?'Explore a complete workflow without a key. Historical public issues may already be resolved.':'Use public, non-sensitive data only. Google may use unpaid inputs and outputs for product improvement and human review.'}</div></div>`;
  if(session?.error) html+=`<div class="info-strip error" role="alert"><div><strong>${esc(session.error.code)}</strong><br>${esc(session.error.message)}<p>Resume continues from the saved checkpoint. An interrupted request may already have been processed; its usage can be unknown. It never switches to a paid provider.</p></div><button class="btn btn-secondary btn-small" data-action="resume" ${busy?'disabled':''}>Resume</button></div>`;
  if(session?.status==='running')html+=`<div class="info-strip teal" role="status"><span class="spinner"></span><div>Agents are working. Each stage is saved locally. You can keep exploring the evidence.</div></div>`;
  return html;
}
function agentPanel() { const events=session?.events||[];return `<div class="agent-card"><div class="agent-heading"><strong>◌ Agent activity</strong><span>${session?esc(session.status.replaceAll('_',' ')):'Ready when you are'}</span></div>${(events.length?events.slice(-5):[{step:'Waiting for feedback',message:config.public_demo?'Load the built-in public sample.':'Load the public demo or upload your CSV.',status:'complete'}]).map(x=>`<div class="agent-event ${x.status==='running'?'running':''}"><span class="event-dot"></span><div><strong>${esc(x.step)}</strong>${esc(x.message)}</div></div>`).join('')}<div class="review-note">${session?.calls_used||0} / ${config.limits?.max_calls_per_run||6} generation calls used in this workspace.</div></div>`; }
function field(name,label,value,large=false,disabled=false) { return `<label class="field"><span class="field-label">${label}</span>${large?`<textarea data-context="${name}" ${disabled?'disabled':''} maxlength="${name==='goals'?1500:500}">${esc(value)}</textarea>`:`<input type="text" data-context="${name}" value="${esc(value)}" maxlength="120" ${disabled?'disabled':''}>`}</label>`; }
function contextPanel() {
  const locked=session&&session.status!=='new',disabled=locked||busy;
  return `<div class="context-column"><section class="card context-card"><div class="card-header"><div><h2>Give the agents context</h2><p>Better context, more useful decisions.</p></div><span class="section-symbol">⌘</span></div><div class="card-body">${field('product','Product',ctx.product,false,disabled)}${field('goals','What are you trying to achieve?',ctx.goals,true,disabled)}${field('deadline','Deadline or planning window',ctx.deadline,false,disabled)}${field('capacity','Team capacity',ctx.capacity,true,disabled)}<label class="field mode-field"><span class="field-label">Analysis mode</span><select id="mode" ${disabled?'disabled':''}><option value="demo" ${mode==='demo'?'selected':''}>Saved sample / local template</option><option value="gemini" ${mode==='gemini'?'selected':''} ${!config.gemini_ready?'disabled':''}>Gemini free tier ${!config.gemini_ready?'· configure .env first':''}</option></select></label><p class="mode-note">${mode==='demo'?'No key needed. Demo uses saved grouping and a local PRD template.':`Model: ${esc(config.model)}. Your key stays on the server.`} ${locked?'Context is locked for this run. Start a new workspace to change it.':''}</p><div class="context-hint">◇ Unknown effort and impact remain unknown. Add constraints rather than invented estimates.</div></div><div class="card-footer"><button class="btn btn-primary btn-full" data-action="analyze" ${!session||disabled?'disabled':''}>${busy?'Working…':'Analyze feedback'} <span>→</span></button><div class="help-caption">Approval comes before PRD generation.</div></div></section>${agentPanel()}</div>`;
}
function feedbackScreen() {
  const rows=session?.feedback||[];
  return intro('01 / Feedback Explorer','Product decisions, backed by evidence.','Turn scattered customer feedback into a focused opportunity and a PRD your team can actually use.')+workflow()+banners()+`<div class="grid-main"><div><section class="card"><div class="card-header"><div><h2>Start with the signal</h2><p>A small, clear sample goes a long way.</p></div><span class="pill neutral">LOCAL FIRST</span></div><div class="card-body"><div class="source-choices"><div class="demo-choice"><div class="source-top"><span class="source-icon">◈</span><span class="pill">NO KEY NEEDED</span></div><h3>Explore the Excalidraw demo</h3><p>12 real public GitHub issues, with linked sources. Historical feedback, curated into three themes.</p><button class="btn btn-secondary btn-small" data-action="demo" ${busy?'disabled':''}>Load public demo ↗</button></div><div class="upload-choice" id="drop-zone"><div class="source-top"><span class="source-icon">⇧</span><span class="pill neutral">CSV</span></div><h3>Bring your own feedback</h3><p>Drop a CSV here or choose a file. Start with up to ${config.limits?.max_rows||30} rows and a text column.</p><button class="btn btn-secondary btn-small" data-action="choose-file" ${busy?'disabled':''}>Choose a CSV</button><input class="input-file" id="csv-file" type="file" accept=".csv,text/csv" aria-label="Upload feedback CSV"></div></div><p class="file-note">UTF-8 · up to 100 KB · required: text · optional metadata supported · <a href="/api/example.csv" download="productsense-example.csv">Download example CSV</a></p></div></section><section class="card"><div class="card-header"><div><h2>Your feedback collection</h2><p>${rows.length?`${rows.length} rows · ${rows.filter(r=>r.source_url).length} linked sources · rows are not people`:'Every decision starts with something someone said.'}</p></div><span class="pill neutral">${rows.length} ROWS</span></div>${rows.length?`<div class="feedback-toolbar"><div class="search-input"><input type="search" id="feedback-search" placeholder="Search feedback or evidence IDs…" aria-label="Search feedback" value="${esc(query)}"></div><span class="tiny muted">Untrusted input</span></div><div id="feedback-rows">${feedbackTable(rows)}</div>`:`<div class="empty-state"><div class="empty-icon">▤</div><h3>Your next product insight starts here</h3><p>Load the demo to try the complete feedback-to-PRD flow, or bring a small sample of your own.</p></div>`}</section></div>${contextPanel()}</div>`;
}
function feedbackTable(rows) { rows=rows.filter(r=>(r.text+' '+r.id).toLowerCase().includes(query.toLowerCase()));return `<div class="table-wrap"><table class="feedback-table"><thead><tr><th>EVIDENCE</th><th>FEEDBACK</th><th>SOURCE</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.id)}</td><td><div class="feedback-text">${esc(r.text)}</div><span class="feedback-topic">${esc(r.topic||'Uploaded feedback')}</span></td><td class="source-cell">${safeUrl(r.source_url)?`<a class="source-link" href="${esc(safeUrl(r.source_url))}" target="_blank" rel="noopener noreferrer">View ↗</a>`:'No link'}</td></tr>`).join('')}</tbody></table></div><div class="table-bottom"><span>${rows.length} matching rows</span><span>Source links are never fetched automatically.</span></div>`; }
function empty(title,body) { return `<section class="card"><div class="empty-state"><div class="empty-icon">◈</div><h3>${esc(title)}</h3><p>${esc(body)}</p><a class="btn btn-primary" href="#feedback">Go to feedback →</a></div></section>`; }
function opportunitiesScreen() {
  let html=intro('02 / Opportunity Prioritisation','Find the problem worth solving.','Compare support in this sample, inspect the evidence, and make the decision yourself.')+workflow()+banners();
  if(!session?.opportunities.length)return html+empty('Your opportunities will appear here','Load feedback, add context, and run analysis first.');
  const opportunity=session.opportunities.find(o=>o.id===selected),canApprove=session.status==='awaiting_approval';
  html+=`<div class="info-strip"><div>Scores compare sample share (70%) and goal-keyword overlap (30%). They are a transparent sorting aid; effort and business impact remain unestimated.</div></div><div class="grid-main opportunity-layout"><section><div class="screen-heading-row"><h2>${session.opportunities.length} opportunities to consider</h2><span class="tiny muted">Limited evidence · human decision</span></div>${session.opportunities.map((o,i)=>`<button class="opportunity-card ${o.id===selected?'selected':''}" data-opportunity="${esc(o.id)}" aria-pressed="${o.id===selected}"><div class="opportunity-top"><div><div class="opportunity-rank">OPPORTUNITY ${String(i+1).padStart(2,'0')} · ${esc(o.id)}</div><h3>${esc(o.title)}</h3></div><span class="radio" aria-hidden="true"></span></div><p>${esc(o.problem)}</p><div class="opportunity-bottom"><span class="pill teal">${o.evidence_ids.length} feedback rows</span><span class="pill neutral">${esc(o.confidence)}</span><span class="score-inline">Sample score <strong>${o.score}</strong>/100</span></div></button>`).join('')}</section><div><section class="card approval-panel"><div class="card-header"><div><h2>Your approval checkpoint</h2><p>The agents wait for your judgement.</p></div></div><div class="card-body"><h3 class="approval-title">${esc(opportunity.title)}</h3><p>${esc(opportunity.rationale)}</p><h3 class="tiny">Evidence</h3><p>${opportunity.evidence_ids.map(id=>`<a href="#evidence/${esc(id)}">[${esc(id)}]</a>`).join(' ')}</p><h3 class="tiny">Assumptions to challenge</h3><ul class="list-clean">${opportunity.assumptions.map(s=>`<li>${esc(s)}</li>`).join('')}</ul><label class="field"><span class="field-label">Correct assumptions & narrow scope</span><textarea id="corrections" maxlength="2000" placeholder="What should the writer change or exclude?" ${!canApprove?'disabled':''}>${esc(session.corrections||corrections)}</textarea></label><label class="approve-check"><input type="checkbox" id="approval-check" ${acknowledged?'checked':''} ${!canApprove?'disabled':''}><span>I approve this opportunity as the PRD scope. I understand that effort, demand and success metrics require validation.</span></label><button class="btn btn-primary btn-full" data-action="approve" ${!canApprove||!acknowledged||busy?'disabled':''}>Approve & write PRD →</button>${session.status==='complete'?'<a class="btn btn-secondary btn-full" href="#editor">Open your PRD →</a>':''}<p class="review-note">Offline templates preserve your corrections for manual reconciliation. Gemini mode uses them during writing and review.</p></div></section>${agentPanel()}</div></div>`;
  return html;
}
function editorScreen() {
  let html=intro('03 / PRD Editor','From opportunity to a shared direction.','An editable document with the evidence, assumptions, and acceptance criteria your team needs.')+workflow()+banners();
  if(!session?.prd_markdown)return html+empty('Your PRD needs an approved opportunity','Compare opportunities, correct assumptions, and approve a scope first.');
  const headings=[...draft.matchAll(/^##\s+(.+)$/gm)].map(m=>m[1]);
  return html+`<div class="editor-layout"><section class="card"><div class="editor-toolbar"><div class="segmented"><button class="segment ${view==='preview'?'active':''}" data-view="preview">Preview</button><button class="segment ${view==='edit'?'active':''}" data-view="edit">Edit Markdown</button></div><div class="editor-actions"><span class="save-status">${dirty?'Unsaved changes':'Saved locally'}</span><button class="btn btn-secondary btn-small" data-action="save" ${busy||session.status!=='complete'?'disabled':''}>Save & check</button><button class="btn btn-secondary btn-small" data-export="md">↓ Markdown</button><button class="btn btn-primary btn-small" data-export="docx">↓ Word</button></div></div>${view==='edit'?`<label class="sr-only" for="markdown-editor">Editable PRD Markdown</label><textarea class="markdown-input" id="markdown-editor" spellcheck="false" maxlength="40000" ${session.status!=='complete'?'disabled':''}>${esc(draft)}</textarea>`:`<article class="markdown-preview">${markdown(draft)}</article>`}</section><aside><div class="editor-outline"><h3>IN THIS DOCUMENT</h3>${headings.map(h=>`<a class="outline-link" href="#section-${slug(h)}" data-outline="${slug(h)}">${esc(h)}</a>`).join('')}<div class="editor-metadata"><strong>Review before delivery</strong>Evidence references are inspectable. Proposals are not validated outcomes.<br><a href="#evidence">Open Evidence & Review →</a></div></div>${agentPanel()}</aside></div>`;
}
function evidenceScreen() {
  let html=intro('04 / Evidence & Review','Keep the reasoning in the open.','Follow each evidence link, inspect the review findings, and identify what still needs a human decision.')+workflow()+banners();
  if(!session)return html+empty('Start with a feedback sample','Your source register and review findings will be collected here.');
  const review=session.review;
  return html+`<div class="review-grid"><section class="card"><div class="card-header"><div><h2>Evidence register</h2><p>Public issue paraphrases or your uploaded rows. Current product state is unverified.</p></div><span class="pill neutral">${session.feedback.length} ROWS</span></div>${session.feedback.map(r=>`<article class="evidence-card" id="evidence-${esc(r.id)}"><div class="evidence-meta"><span class="evidence-id">${esc(r.id)}</span>${safeUrl(r.source_url)?`<a class="source-link" href="${esc(safeUrl(r.source_url))}" target="_blank" rel="noopener noreferrer">Open original source ↗</a>`:'<span class="tiny muted">No external source supplied</span>'}</div><p>${esc(r.text)}</p><small class="feedback-topic">${esc(r.source_kind)}${r.topic?' · '+esc(r.topic):''}</small></article>`).join('')}</section><aside class="review-sidebar"><section class="card"><div class="card-header"><div><h2>Review findings</h2><p>Automated checks · human review pending</p></div></div><div class="review-metrics"><div class="review-metric"><strong>${review.requirements_count}</strong><span>requirements detected</span></div><div class="review-metric"><strong>${Math.round((review.evidence_coverage||0)*100)}%</strong><span>with source or proposal label</span></div></div><div class="card-body">${review.issues.length?review.issues.map(issue=>`<div class="review-issue"><span>△</span><div><strong>${esc(issue.severity)}</strong>${esc(issue.message)}</div></div>`).join(''):'<p class="tiny muted">Generate a PRD to run structural checks and review.</p>'}<p class="review-note">${review.requirements_with_acceptance === undefined ? "Acceptance mapping has not been checked for this saved version." : `${review.requirements_with_acceptance} / ${review.requirements_count} requirements have linked AC-numbered Given/When/Then criteria.`}</p><p class="review-note"><strong>Evidence</strong> describes source reports. <strong>User constraints</strong> define approved scope. <strong>Proposals</strong> describe suggested behaviour. <strong>Assumptions</strong> remain unverified.</p><p class="review-note">A valid citation ID does not prove that its source supports a claim. This percentage measures document traceability, not factual accuracy.</p></div></section><section class="card"><div class="card-header"><h2>What we still do not know</h2></div><div class="card-body"><ul class="facts-list"><li><strong>Actual demand</strong> — a curated sample cannot represent all customers.</li><li><strong>Business impact</strong> — no revenue or adoption forecast is inferred.</li><li><strong>Effort & feasibility</strong> — engineering estimation is required.</li><li><strong>Current behavior</strong> — historical issues may be resolved.</li></ul><a class="btn btn-secondary btn-full" href="/api/sessions/${session.id}/backup">↓ Download workspace backup</a><p class="review-note">Backup contains feedback and draft, never the server API key. Keep runtime/ for resumable graph checkpoints.</p></div></section>${agentPanel()}</aside></div>`;
}
function render() {
  const current=route();
  $('#navigation').innerHTML=screens.map((s,i)=>`<a class="nav-item ${s[0]===current?'active':''}" href="#${s[0]}" ${s[0]===current?'aria-current="page"':''}><span aria-hidden="true">${s[2]}</span><span>${s[1]}</span><span class="nav-number">0${i+1}</span></a>`).join('');
  $('#breadcrumb-title').textContent=screens.find(s=>s[0]===current)[1];
  $('#main').innerHTML=({feedback:feedbackScreen,opportunities:opportunitiesScreen,editor:editorScreen,evidence:evidenceScreen,traceability:traceScreen}[current])();
  if(current==='evidence'&&location.hash.includes('/'))document.getElementById('evidence-'+decodeURIComponent(location.hash.split('/')[1]))?.scrollIntoView({block:'center',behavior:'smooth'});
  bindDrop();
  if(typeof renderChanges==="function")renderChanges();
  applyPublicMode();
  if(typeof renderLedgerPreview==='function')renderLedgerPreview(current);
  if(current==='evidence'&&typeof researchPanel==='function')researchPanel();
}
async function perform(action) {
  if(busy)return;
  busy=true;
  document.querySelectorAll('[data-action], [data-change], [data-export]').forEach(b=>b.disabled=true);
  try {await action();} catch(error){toast(error.message,true);} finally {busy=false;render();poll();}
}
async function loadDemo() { if(dirty){toast('Save your PRD changes before opening a new workspace.',true);return;} await perform(async()=>{useSession(await api('/api/sessions/demo',{method:'POST',body:JSON.stringify({context:ctx,mode,public_data_confirmed:typeof publicConsent!=="undefined"&&publicConsent})}));query='';selected='';acknowledged=false;corrections='';location.hash='feedback';toast('Public demo loaded. Add context, then analyze.');}); }
async function uploadFile(file) {
  if(!file)return;
  if(dirty){toast('Save your PRD changes before opening a new workspace.',true);return;}
  if(file.size>(config.limits?.max_file_bytes||100000)){toast('CSV is too large. Start with a sample under 100 KB.',true);return;}
  await perform(async()=>{const form=new FormData();form.append('file',file);form.append('context',JSON.stringify(ctx));form.append('mode',mode);useSession(await api('/api/sessions/upload',{method:'POST',body:form}));selected='';acknowledged=false;corrections='';query='';location.hash='feedback';toast('CSV validated and loaded.');});
}
async function save() { if(!session||!dirty)return;useSession(await api(`/api/sessions/${session.id}/prd`,{method:'PATCH',body:JSON.stringify({markdown:draft,actor:typeof editorActor!=="undefined"?editorActor:"manual",scope_approved:typeof scopeConsent!=="undefined"&&scopeConsent})}));dirty=false;storage.remove('productsense-draft-'+session.id);toast('PRD saved. Structural checks refreshed.'); }
async function poll() {
  if(polling||session?.status!=='running')return;
  polling=true;
  try {
    while(session?.status==='running') {await new Promise(r=>setTimeout(r,1100)); const previous=session.status; useSession(await api('/api/sessions/'+session.id));render();if(previous==='running'&&session.status==='awaiting_approval'){location.hash='opportunities';toast('Analysis complete. Choose an opportunity to approve.');}if(session.status==='complete'){draft=session.prd_markdown;location.hash='editor';toast('Your PRD is ready for editing and review.');}}
  }catch(e){toast('Connection interrupted. Your last saved stage is on the server. Reload to reconnect.',true);}finally{polling=false;}
}
function bindDrop() {const zone=$('#drop-zone');if(!zone)return;zone.addEventListener('dragover',e=>{e.preventDefault();zone.classList.add('drag-over')});zone.addEventListener('dragleave',()=>zone.classList.remove('drag-over'));zone.addEventListener('drop',e=>{e.preventDefault();zone.classList.remove('drag-over');uploadFile(e.dataTransfer.files[0])});}
document.addEventListener('input',e=>{
  if(e.target.dataset.context)ctx[e.target.dataset.context]=e.target.value;
  if(e.target.id==='corrections')corrections=e.target.value;
  if(e.target.id==='feedback-search'){query=e.target.value;$('#feedback-rows').innerHTML=feedbackTable(session.feedback);}
  if(e.target.id==='markdown-editor'){draft=e.target.value;dirty=true;storage.set('productsense-draft-'+session.id,draft);const label=$('.save-status');if(label)label.textContent='Unsaved changes';}
});
document.addEventListener('change',e=>{
  if(e.target.id==='mode'){mode=e.target.value;render();}
  if(e.target.id==='csv-file')uploadFile(e.target.files[0]);
  if(e.target.id==='approval-check'){acknowledged=e.target.checked;render();}
});
document.addEventListener('click',async e=>{
  const opportunity=e.target.closest('[data-opportunity]');if(opportunity){selected=opportunity.dataset.opportunity;acknowledged=false;render();return;}
  const outline=e.target.closest('[data-outline]');if(outline){e.preventDefault();if(view!=='preview'){view='preview';render();}document.getElementById('section-'+outline.dataset.outline)?.scrollIntoView({behavior:'smooth'});return;}
  const segment=e.target.closest('[data-view]');if(segment){view=segment.dataset.view;render();return;}
  const exp=e.target.closest('[data-export]');if(exp){await perform(async()=>{await save();const url=`/api/sessions/${session.id}/export?format=${exp.dataset.export}&include_review=${Boolean($("#export-review")?.checked)}`;const response=await fetch(url);if(!response.ok)throw new Error('Export unavailable. Finish generation first.');const a=document.createElement('a');a.href=URL.createObjectURL(await response.blob());a.download='productsense-prd.'+exp.dataset.export;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);});return;}
  const button=e.target.closest('[data-action]');if(!button)return;
  const action=button.dataset.action;
  if(action==='demo')return loadDemo();
  if(action==='choose-file')return $('#csv-file').click();
  if(action==='save')return perform(save);
  if(action==='analyze')return perform(async()=>{if(!ctx.product.trim()||!ctx.goals.trim())throw new Error('Add a product name and goal before analyzing.');useSession(await api(`/api/sessions/${session.id}/context`,{method:'PATCH',body:JSON.stringify({context:ctx,mode,public_data_confirmed:typeof publicConsent!=="undefined"&&publicConsent})}));useSession(await api(`/api/sessions/${session.id}/analyze`,{method:'POST'}));});
  if(action==='approve')return perform(async()=>{if(!acknowledged)throw new Error('Confirm the scope approval checkbox.');useSession(await api(`/api/sessions/${session.id}/approve`,{method:'POST',body:JSON.stringify({opportunity_id:selected,corrections,clarification:$("#clarification")?.value||"Unknown"})}));});
  if(action==='resume')return perform(async()=>useSession(await api(`/api/sessions/${session.id}/resume`,{method:'POST'})));
});
$('#start-over').addEventListener('click',()=>{if(dirty){toast('Save your PRD changes before starting a new workspace.',true);return;}session=null;selected='';draft='';acknowledged=false;corrections='';query='';storage.remove('productsense-session');location.hash='feedback';render();});
window.addEventListener('hashchange',render);
window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue='';}});
(async()=>{try{config=await api('/api/config');const saved=storage.get('productsense-session');if(saved){try{useSession(await api('/api/sessions/'+saved));const local=storage.get('productsense-draft-'+saved);if(local&&local!==session.prd_markdown){draft=local;dirty=true;toast('Recovered your unsaved local draft. Save to update exports.');}}catch{storage.remove('productsense-session');toast('Previous workspace unavailable on this server. Start with the demo.',true);}}render();poll();}catch(e){$('#main').innerHTML=`<div class="error-page"><h1>The server is unavailable</h1><p>${esc(e.message)}</p><p>Run the Python server and reload this page.</p><button class="btn btn-primary" id="reload-page">Retry</button></div>`;$('#reload-page').onclick=()=>location.reload();}})();

function applyPublicMode(){if(!config.public_demo)return;
 document.querySelectorAll('.upload-choice,.file-note').forEach(x=>x.remove());
 const select=document.querySelector('#mode');if(select){select.value='demo';select.closest('.mode-field').style.display='none';}
 document.querySelectorAll('option[value="gemini"]').forEach(x=>x.remove());
 document.querySelectorAll('.mode-note').forEach(x=>x.textContent='Public saved demo: built-in sample and local templates only. No live AI or CSV uploads. Workspaces expire; export to keep your work.');
 const badge=document.querySelector('.workspace-label span');if(badge)badge.textContent='SAVED DEMO';
 document.querySelectorAll('.empty-state p').forEach(x=>x.textContent='Load the built-in public demo to try the complete feedback-to-PRD flow.');
 const budget=document.querySelector('.budget-card p');if(budget)budget.textContent='Temporary server storage. Export to keep your work.';
}
