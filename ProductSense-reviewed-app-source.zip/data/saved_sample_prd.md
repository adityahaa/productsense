# Excalidraw PRD — Export and portability

Saved sample / local template output. No model call was made. Proposed scope requires human review.

## Problem statement
Reported needs concerning export and portability. Validate a current reproduction and the affected user segment before choosing a solution. [EX-1800] [EX-1972] [EX-6949] [EX-182]

The evidence describes reported needs. Historical public issues may already be resolved; reproduce the problem in the current product before committing. The sample cannot establish affected customer numbers, revenue, market demand, or business impact.

## Target users
Assumption: Diagram authors sharing drawings outside the editor. Validate this segment with interviews and current product observation. Issue authors are not a representative customer sample.

## Goals
- Proposed direction: a predictable export workflow that preserves the visible drawing.
- User-supplied product goal: Make sharing diagrams outside the editor more reliable.
- Make the selected user action understandable and recoverable. Validate fit with the goal before implementation.

## Non-goals
- Rebuilding the entire product or addressing every feedback theme in this release.
- Promising revenue, retention, adoption, delivery dates, or engineering effort without evidence.
- Adding unrelated integrations, permissions or infrastructure without a separate decision.

## Proposed success metrics
- Proposal: measure successful completion of the selected action divided by attempts in an agreed usability test. Baseline and target: unknown; establish before release.
- Proposal: measure the rate of recoverable failures using consent-aware instrumentation. Baseline, target and observation window: to be agreed.
- Proposal: collect task-completion feedback from the validated user segment. No customer numbers are available in this sample.

## Requirements
- R1 — Evidence-informed problem / proposed solution: Choose an export format, preview the result, and download the selected drawing. [EX-1800] [EX-1972] [EX-6949] [EX-182]
- R2 — Proposal: show a clear error and recovery action for invalid inputs or unsupported states; preserve existing work.
- R3 — Proposal: make the primary flow operable with keyboard controls, meaningful labels and visible focus.
- R4 — Assumption: preserve compatibility with existing saved drawings; confirm the actual format and support policy with engineering.

## User stories
- As a member of the proposed target segment, I want a predictable export workflow that preserves the visible drawing, so I can complete the intended task without an unexplained workaround. Problem evidence: [EX-1800]; the solution is a proposal.
- As a person encountering a failure, I want a useful recovery message so I can continue without losing my work. Proposal linked to R2.

## Acceptance criteria
- AC1 / R1 / Proposal: Given a drawing with text and shapes, when an author exports it in a supported format, then the downloaded file opens and contains the selected content.
- AC2 / R2 / Proposal: Given an unsupported format or a failed export, when export is attempted, then the editor shows an actionable error and preserves the drawing.
- AC3 / R3 / Proposal: Given keyboard-only navigation, when the primary action is reached and activated, then every control has a visible focus state, a programmatic label, and no focus trap.
- AC4 / R4 / Assumption: Given an existing supported drawing fixture, when it is opened and saved through the new flow, then an automated comparison confirms its original content remains intact.
- AC5 / R1 / Proposal: Given a cancelled action, when the user returns to editing, then the prior drawing and selection remain available.

## Edge cases
- Empty and very large drawings; mixed scripts and unavailable fonts; unsupported or malformed input.
- Offline operation, repeated activation, cancellation, permissions mismatch and interrupted saving.
- Validate which cases apply to the selected opportunity; defer unrelated cases explicitly.

## Non-functional requirements
- Proposal: preserve user work on failure; avoid sensitive data in logs.
- Proposal: support keyboard and screen-reader use; verify with accessibility testing.
- Proposal: establish a performance baseline on an agreed reference drawing and device before setting a latency target.
- Assumption: use the product's existing browser support policy; confirm policy with the team.

## Dependencies
- Engineering discovery: current implementation, affected formats, existing tests and compatibility requirements.
- Design review of controls and recovery states. Team capacity supplied by the user: Not estimated — validate with engineering
- Deadline supplied by the user: Not set — agree with the team. Feasibility is unestimated; this is not a delivery commitment.

## Risks
- Historical requests may describe functionality now available. Mitigation: inspect current behavior and issue resolution before scope approval.
- Small, selected public sample can misrepresent demand. Mitigation: validate with additional current evidence.
- Compatibility and accessibility regressions. Mitigation: test agreed fixtures and assistive workflows before release.
- Corrections may contradict the proposed scope. Resolve conflicts in human review before implementation.

## Assumptions
- Current demand, representativeness and implementation effort are unverified.
- The proposed solution is a starting point, not proven customer demand or an engineering estimate.
- Human corrections and constraints (verbatim, supplied by the approver):

> Validate keyboard-only access before release.

Treat these constraints as authoritative scope input after human review. Revise any generic proposal above that conflicts with them; this offline template cannot semantically reconcile arbitrary corrections.

## Open questions
- Can the team reproduce this problem in the current product? Which requests are already resolved?
- Who is affected today, in what context, and what workaround do they use?
- Which concrete user action and format belongs in the smallest release?
- What baseline, success target, capacity and delivery date can the team validate?
- Do the human corrections require removing or rewriting any requirement?

## MVP scope
- In: discover and reproduce the selected problem, validate one narrow proposed action, implement R1–R3 where applicable, and test the agreed acceptance cases.
- Conditional: R4 only after confirming compatibility requirements.
- Out: unrelated themes, unsupported business forecasts, and unvalidated expansion.
- Release gate: human approval of this edited PRD, current evidence verification and engineering feasibility review.

## Evidence register
- [EX-1800](https://github.com/excalidraw/excalidraw/issues/1800) — Add a PDF export option alongside image and SVG downloads so diagrams can be shared as documents.
- [EX-1972](https://github.com/excalidraw/excalidraw/issues/1972) — Offer SVG text as vector outlines because some viewers cannot load the external fonts and render the exported diagram incorrectly.
- [EX-6949](https://github.com/excalidraw/excalidraw/issues/6949) — Export a presentation to PDF so attendees can receive a copy after the presentation.
- [EX-182](https://github.com/excalidraw/excalidraw/issues/182) — Provide an option to download a drawing in SVG format.

Evidence is linked to the reported problem, not proof that the proposed requirements solve it.
