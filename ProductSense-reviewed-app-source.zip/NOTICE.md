# Third-party and data notices

MIT covers project-authored application code only. Dependencies retain their own licences; installation uses the pinned requirements. Public Excalidraw sample rows are short paraphrases of historical GitHub issue reports, with original source URLs preserved in data/demo_feedback.json. Original reports and third-party marks retain their authors rights. Public accessibility is not a blanket licence grant. Saved PRDs are labelled examples/proposals and are not customer facts. No historical research archives, private assessments or databases are distributed here.
