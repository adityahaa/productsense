import re
import sqlite3
from collections import Counter
from typing import TypedDict, Any
from langgraph.graph import StateGraph, START, END
from langgraph.types import interrupt, Command
from langgraph.checkpoint.sqlite import SqliteSaver
from .models import AnalysisOutput, DraftOutput, ReviewOutput
from .prd import sample_prd, review_prd, REQUIRED_SECTIONS
from .provider import GeminiProvider, ProviderFailure
from .evidence import without_server_register
from .analysis import prioritize_groups, scope_checks


class ProductState(TypedDict, total=False):
    id: str
    mode: str
    context: dict
    feedback: list[dict]
    groups: list[dict]
    opportunities: list[dict]
    selected_opportunity_id: str
    corrections: str
    prd_markdown: str
    prd_model_markdown: str
    initial_model_markdown: str
    review_history: list[dict]
    review: dict
    revision_count: int
    status: str
    clarification: str


STOPWORDS = set('the a an and or to of for in on is are as with this that it be can from by so when user users'.split())


def tokens(text):
    return set(re.findall(r'[a-z]{3,}', text.lower())) - STOPWORDS


def local_groups(feedback):
    """Small-sample lexical retrieval/grouping; no embeddings or network."""
    groups = {}
    for row in feedback:
        if row.get('topic'):
            title = row['topic']
        else:
            text = row['text'].lower()
            title = next((name for name, words in [
                ('Export and portability', ('export', 'pdf', 'svg', 'download')),
                ('Text editing', ('text', 'font', 'formatting', 'label')),
                ('Sharing and self-hosting', ('share', 'sharing', 'collaborat', 'hosting', 'docker')),
                ('Reliability and recovery', ('error', 'crash', 'lost', 'fail')),
            ] if any(word in text for word in words)), 'Other reported needs')
        groups.setdefault(title, []).append(row)
    return [{'title': title, 'problem': 'Reported needs concerning ' + title.lower() + '. Validate a current reproduction and the affected user segment before choosing a solution.',
             'evidence_ids': [row['id'] for row in rows],
             'assumptions': ['Current demand, representativeness and implementation effort are unverified.']}
            for title, rows in groups.items()]


class Workflow:
    def __init__(self, store, path=None, *, saver=None):
        self.store = store
        self.provider = GeminiProvider(store)
        self.connection = None if saver is not None else sqlite3.connect(path / 'checkpoints.sqlite', check_same_thread=False)
        self.saver = saver if saver is not None else SqliteSaver(self.connection)
        builder = StateGraph(ProductState)
        builder.add_node('analyze', self.analyze)
        builder.add_node('prioritize', self.prioritize)
        builder.add_node('approve', self.approve)
        builder.add_node('write_prd', self.write_prd)
        builder.add_node('review', self.review)
        builder.add_node('revise', self.revise)
        builder.add_node('finish', self.finish)
        builder.add_edge(START, 'analyze')
        builder.add_edge('analyze', 'prioritize')
        builder.add_edge('prioritize', 'approve')
        builder.add_edge('approve', 'write_prd')
        builder.add_edge('write_prd', 'review')
        builder.add_conditional_edges('review', lambda s: 'revise' if s['mode'] == 'gemini' and s.get('revision_count', 0) < 1 and s['review'].get('needs_revision') else 'finish')
        builder.add_edge('revise', 'review')
        builder.add_edge('finish', END)
        self.graph = builder.compile(checkpointer=self.saver)

    def config(self, sid):
        return {'configurable': {'thread_id': sid}, 'recursion_limit': 15}

    def persist(self, state, changes):
        if 'prd_markdown' in changes:
            changes['version_origin']='saved-template' if state['mode']=='demo' else ('model-revision' if changes.get('revision_count') else 'model-draft')
        self.store.update(state['id'], **changes)
        return changes

    def analyze(self, state):
        self.store.event(state['id'], 'Analysis', 'Grouping evidence. Feedback is treated as untrusted data.', 'running')
        if state['mode'] == 'demo':
            groups = local_groups(state['feedback'])
        else:
            result = self.provider.generate(state['id'], 'analysis', {'context': state['context'], 'feedback': state['feedback']}, AnalysisOutput)
            groups = result['groups']
        original = {row['id'] for row in state['feedback']}
        assigned = [rid for group in groups for rid in group['evidence_ids']]
        if set(assigned) != original or len(assigned) != len(set(assigned)):
            raise ProviderFailure('evidence_validation', 'Analysis omitted, duplicated or invented evidence IDs. Progress saved; resume to retry.')
        self.store.event(state['id'], 'Analysis', f'{len(groups)} problem groups grounded in {len(original)} feedback rows. Rows are not people.')
        return self.persist(state, {'groups': groups})

    def prioritize(self, state):
        opportunities=prioritize_groups(state['groups'],state['feedback'],state['context'])
        self.store.event(state['id'],'Prioritisation','Compared sample support and lexical goal fit. Recommendations are advisory; awaiting approval.')
        return self.persist(state,{'opportunities':opportunities})

    def legacy_prioritize(self, state):
        goals = tokens(state['context']['goals'])
        records = {r['id']: r for r in state['feedback']}
        opportunities = []
        for i, group in enumerate(state['groups'], 1):
            ids = group['evidence_ids']
            words = tokens(' '.join(records[rid]['text'] for rid in ids))
            overlap = len(goals & words) / max(len(goals), 1)
            share = len(ids) / len(records)
            # Transparent navigation aid, not a claimed value/effort/ROI estimate.
            score = round(100 * (0.7 * share + 0.3 * overlap))
            opportunities.append({**group, 'id': f'OP-{i}', 'score': score,
                'confidence': 'Limited — sample only',
                'rationale': f'{len(ids)} of {len(records)} supplied rows; {len(goals & words)} goal-keyword matches. Score = 70 × sample share + 30 × goal-keyword overlap. No effort, revenue or business impact estimate.',
                'score_components': {'sample_share': share, 'goal_keyword_overlap': overlap}})
        opportunities.sort(key=lambda x: (-x['score'], x['id']))
        self.store.event(state['id'], 'Prioritisation', 'Compared sample support and lexical goal fit. Awaiting your opportunity choice and corrected assumptions.')
        return self.persist(state, {'opportunities': opportunities})

    def approve(self, state):
        decision = interrupt({'message': 'Choose an opportunity and correct assumptions before PRD writing.',
                              'opportunities': state['opportunities']})
        if decision.get('opportunity_id') not in {x['id'] for x in state['opportunities']}:
            raise ProviderFailure('approval_invalid', 'Approval refers to an unknown opportunity.')
        self.store.event(state['id'], 'Approval', 'Opportunity explicitly approved by the user. Corrections recorded as human input.')
        return self.persist(state, {'selected_opportunity_id': decision['opportunity_id'], 'corrections': decision.get('corrections', ''),'clarification':decision.get('clarification','Unknown')})

    def payload(self, state):
        selected = next(x for x in state['opportunities'] if x['id'] == state['selected_opportunity_id'])
        # Local retrieval: only selected group evidence is sent to PRD nodes.
        return {'context': state['context'], 'opportunity': selected, 'corrections': state.get('corrections', ''),
                'clarification':state.get('clarification','Unknown — validate current behaviour and acceptance fixtures.'),
                'feedback': [r for r in state['feedback'] if r['id'] in selected['evidence_ids']],
                'required_sections': REQUIRED_SECTIONS}

    def write_prd(self, state):
        self.store.event(state['id'], 'PRD writer', 'Writing the approved scope with traceable evidence and explicit proposals.', 'running')
        draft = sample_prd(state) if state['mode'] == 'demo' else self.provider.generate(state['id'], 'draft', self.payload(state), DraftOutput)['markdown']
        model_draft = draft
        if state['mode'] == 'gemini':
            draft = self.append_sources(draft, state)
        return self.persist(state, {'prd_markdown': draft, 'prd_model_markdown': model_draft,
                                    'initial_model_markdown': model_draft, 'revision_count': 0})

    def append_sources(self, draft, state):
        rows = self.payload(state)['feedback']
        register = '\n'.join(f"- [{r['id']}]({r['source_url']})" if r['source_url'] else f"- [{r['id']}] — uploaded row; no external source supplied" for r in rows)
        return without_server_register(draft) + '\n\n## Source links (server-attached)\n' + register

    def review(self, state):
        self.store.event(state['id'], 'Reviewer', 'Checking PRD structure, evidence references and unsupported claims.', 'running')
        review = review_prd(state['prd_markdown'], state['feedback'])
        selected=next((o for o in state['opportunities'] if o['id']==state.get('selected_opportunity_id')), {})
        review['issues']+=scope_checks(state['prd_markdown'],{'excluded':selected.get('scope_excluded','')})
        review['check_types']={'deterministic':'structure, IDs, literal wording and scope candidates; not semantic truth','model':'one review call when live; judgement may miss errors','human':'pending'}
        generated_issues = []
        if state['mode'] == 'gemini':
            # Review once by model; second review after revision is deterministic to bound cost.
            if not state.get('revision_count', 0):
                generated_issues = self.provider.generate(state['id'], 'review', {**self.payload(state), 'markdown': state['prd_markdown']}, ReviewOutput)['issues']
            else:
                review['issues'].append({'severity': 'warning', 'message': 'One revision completed. Final recheck is structural only; no second model review.'})
        review['issues'] = ([{**i,'check_type':'model judgement'} for i in generated_issues] + [{**i,'check_type':'deterministic check'} for i in review['issues']])[:30]
        review['needs_revision'] = bool(generated_issues or any(x['severity'] == 'error' for x in review['issues']))
        self.store.event(state['id'], 'Reviewer', f"Found {len(review['issues'])} review items. Human quality review remains required.")
        return self.persist(state, {'review': review, 'review_history': state.get('review_history', []) + [review]})

    def revise(self, state):
        self.store.event(state['id'], 'Revision', 'Applying one bounded revision to the review findings.', 'running')
        draft = self.provider.generate(state['id'], 'revise', {**self.payload(state), 'markdown': state['prd_markdown'], 'review': state['review']}, DraftOutput)['markdown']
        return self.persist(state, {'prd_markdown': self.append_sources(draft, state), 'prd_model_markdown': draft, 'revision_count': 1})

    def finish(self, state):
        self.store.event(state['id'], 'Complete', 'Draft ready to edit and export. Review warnings before implementation.')
        return self.persist(state, {'status': 'complete','downstream_needs_review':False})

    def run(self, sid, operation='start', decision=None):
        try:
            config = self.config(sid)
            if operation == 'approve':
                initial: Any = Command(resume=decision)
            elif operation == 'resume':
                snapshot = self.graph.get_state(config)
                # A crash may precede the first checkpoint.
                initial = None if snapshot.values else self.store.get(sid)
            else:
                initial = self.store.get(sid)
            result = self.graph.invoke(initial, config)
            status = 'awaiting_approval' if result.get('__interrupt__') else 'complete'
            self.store.update(sid, status=status, error=None)
        except ProviderFailure as exc:
            self.store.event(sid, 'Paused', exc.message, 'paused')
            self.store.update(sid, status='paused', error={'code': exc.code, 'message': exc.message})
        except Exception:
            # No raw exceptions from user/model content or secrets in logs.
            self.store.update(sid, status='error', error={'code': 'workflow_error', 'message': 'Workflow stopped unexpectedly. Progress saved; export a backup and try Resume.'})
