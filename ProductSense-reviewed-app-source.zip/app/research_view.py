"""Local-only research and dataset inspection routes (read-only).
Registered ONLY when PRODUCTSENSE_RESEARCH_MODE=1 and the app is not a public demo, so public mode never exposes
experiment files. Slot IDs are validated against a strict pattern and resolved paths must stay inside results/."""
import importlib.util, json, os, re
from pathlib import Path
from fastapi import HTTPException

ROOT = Path(__file__).resolve().parent.parent
V3 = ROOT / 'research' / 'study_v3'
SLOT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9._-]{0,150}$')


def research_enabled(public_demo):
    return (not public_demo) and os.getenv('PRODUCTSENSE_RESEARCH_MODE') == '1'


def _validator():
    spec = importlib.util.spec_from_file_location('study_v3_validate_dataset', V3 / 'validate_dataset.py')
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def install_research(app, public_demo=False, base=V3):
    if not research_enabled(public_demo):
        return False
    results = base / 'results'
    assess = base / 'assessments'

    @app.get('/api/research/dataset')
    def dataset():
        data = json.loads((base / 'dataset' / 'cases.json').read_text(encoding='utf-8'))
        sources = json.loads((base / 'dataset' / 'sources.json').read_text(encoding='utf-8'))
        report = _validator().validate(base / 'dataset', base / 'raw_github')
        cases = [{**{k: c[k] for k in ('id', 'product', 'split', 'tags', 'opportunity', 'scope_in', 'scope_out', 'scope_origin')},
                  'needs': c['important_needs'],
                  'sources': [{k: sources[s][k] for k in ('id', 'url', 'title', 'observed_state', 'state_observed_utc', 'source_updated_utc',
                                                        'excerpt_truncated', 'repo_license', 'repo_license_verification', 'excerpt')} for s in c['source_ids']]}
                 for c in data['cases']]
        warnings = [f for f in report['findings'] if f['severity'] in ('error', 'warning')]
        return {'summary': report['summary'], 'cases': cases, 'warnings': warnings,
                'notice': 'Curator-selected cases; scope and needs are researcher-authored. Tracker status is historical and may not reflect current behaviour.'}

    @app.get('/api/research/runs')
    def runs():
        out = []
        for f in sorted(results.glob('*/final.json')) if results.exists() else []:
            r = json.loads(f.read_text(encoding='utf-8'))
            out.append({k: r.get(k) for k in ('id', 'case', 'arm', 'repeat', 'split', 'status', 'detail', 'usage_actual', 'model_versions_returned',
                                               'api_latency_sum_s', 'wall_clock_s', 'document_id', 'deterministic_structure')})
            a = assess / f"{r.get('document_id')}.json"
            if r.get('document_id') and a.exists():
                v = json.loads(a.read_text(encoding='utf-8')).get('validation', {})
                out[-1]['assessment'] = {'valid': v.get('valid'), 'errors': v.get('errors', [])[:5]}
        return {'runs': out, 'note': 'Labels are visible here (unblinded). Never give this view to blinded reviewers.'}

    @app.get('/api/research/runs/{slot_id}/prd')
    def run_prd(slot_id: str):
        if not SLOT_RE.fullmatch(slot_id) or '..' in slot_id:
            raise HTTPException(400, 'Invalid run id.')
        path = (results / slot_id / 'prd.md').resolve()
        if results.resolve() not in path.parents or not path.is_file():
            raise HTTPException(404, 'No PRD for this run.')
        return {'id': slot_id, 'markdown': path.read_text(encoding='utf-8')}
    return True
