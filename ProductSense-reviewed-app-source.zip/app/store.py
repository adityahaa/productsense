import json
import sqlite3
import threading
import hashlib
import difflib
from datetime import datetime, timezone
from pathlib import Path
from .config import MAX_CALLS, MAX_DAILY_CALLS


class Store:
    def __init__(self, path: Path, recover_running: bool = True, research_phase: str | None = None):
        self.research_phase = research_phase
        path.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.conn = sqlite3.connect(path / 'productsense.sqlite', check_same_thread=False)
        self.conn.executescript('''PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS cache(key TEXT PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS calls(id INTEGER PRIMARY KEY, session_id TEXT, day TEXT);''')
        columns = {row[1] for row in self.conn.execute('PRAGMA table_info(calls)')}
        for name, definition in {'task': "TEXT DEFAULT 'unknown'", 'model': 'TEXT',
                'status': "TEXT DEFAULT 'legacy_attempt'", 'created_utc': 'TEXT',
                'finished_utc': 'TEXT', 'usage': 'TEXT', 'error_code': 'TEXT'}.items():
            if name not in columns:
                self.conn.execute(f'ALTER TABLE calls ADD COLUMN {name} {definition}')
        self.conn.execute('''CREATE TABLE IF NOT EXISTS cache_replays(
            id INTEGER PRIMARY KEY, session_id TEXT, task TEXT, model TEXT, created_utc TEXT, origin_utc TEXT)''')
        self.conn.commit()
        self.conn.execute('CREATE TABLE IF NOT EXISTS phase_budgets(name TEXT PRIMARY KEY, start_call_id INTEGER NOT NULL, cap INTEGER NOT NULL)')
        self.conn.executescript('''CREATE TRIGGER IF NOT EXISTS enforce_phase_budget BEFORE INSERT ON calls
            WHEN EXISTS(SELECT 1 FROM phase_budgets p WHERE
              (SELECT COUNT(*) FROM calls c WHERE c.id>p.start_call_id)>=p.cap)
            BEGIN SELECT RAISE(ABORT, 'Active phase attempt ceiling reached'); END;''')
        self.conn.commit()
        self.conn.execute('CREATE TABLE IF NOT EXISTS document_versions(id INTEGER PRIMARY KEY, session_id TEXT NOT NULL, created_utc TEXT NOT NULL, origin TEXT NOT NULL, markdown TEXT NOT NULL, digest TEXT NOT NULL)')
        self.conn.execute('CREATE TABLE IF NOT EXISTS analysis_edits(id INTEGER PRIMARY KEY, session_id TEXT NOT NULL, created_utc TEXT NOT NULL, before_json TEXT NOT NULL, after_json TEXT NOT NULL, reason TEXT NOT NULL)')
        self.conn.commit()
        with self.lock:
            for _, raw in self.conn.execute('SELECT id,data FROM sessions').fetchall() if recover_running else []:
                data = json.loads(raw)
                if data['status'] == 'running':
                    data.update(status='paused', error={'code': 'interrupted', 'message': 'The server restarted. Resume from the last saved checkpoint.'})
                    self.save(data)

    def save(self, data):
        with self.lock, self.conn:
            markdown=data.get('prd_markdown','')
            if markdown:
                last=self.conn.execute('SELECT markdown FROM document_versions WHERE session_id=? ORDER BY id DESC LIMIT 1',(data['id'],)).fetchone()
                if not last:
                    old=self.conn.execute('SELECT data FROM sessions WHERE id=?',(data['id'],)).fetchone()
                    oldtext=json.loads(old[0]).get('prd_markdown','') if old else ''
                    if oldtext and oldtext!=markdown:
                        self._version(data['id'],oldtext,'legacy-preserved')
                if not last or last[0]!=markdown:
                    self._version(data['id'],markdown,data.get('version_origin','legacy-preserved'))
            self.conn.execute('INSERT OR REPLACE INTO sessions VALUES (?,?)', (data['id'], json.dumps(data)))
        return data

    def _version(self,sid,markdown,origin):
        self.conn.execute('INSERT INTO document_versions(session_id,created_utc,origin,markdown,digest) VALUES (?,?,?,?,?)',
            (sid,datetime.now(timezone.utc).isoformat(),origin,markdown,hashlib.sha256(markdown.encode()).hexdigest()))

    def versions(self,sid):
        with self.lock:
            rows=self.conn.execute('SELECT id,created_utc,origin,markdown,digest FROM document_versions WHERE session_id=? ORDER BY id',(sid,)).fetchall()
        previous=''; result=[]
        for vid,created,origin,markdown,digest in rows:
            delta='\n'.join(difflib.unified_diff(previous.splitlines(),markdown.splitlines(),fromfile='previous',tofile=f'version-{vid}',lineterm=''))
            result.append({'id':vid,'created_utc':created,'origin':origin,'markdown':markdown,'sha256':digest,'diff':delta})
            previous=markdown
        return result

    def audit_analysis(self,sid,before,after,reason):
        with self.lock,self.conn:
            self.conn.execute('INSERT INTO analysis_edits(session_id,created_utc,before_json,after_json,reason) VALUES (?,?,?,?,?)',
                (sid,datetime.now(timezone.utc).isoformat(),json.dumps(before),json.dumps(after),reason))

    def analysis_history(self,sid):
        with self.lock:
            rows=self.conn.execute('SELECT id,created_utc,before_json,after_json,reason FROM analysis_edits WHERE session_id=? ORDER BY id',(sid,)).fetchall()
        return [{'id':r[0],'created_utc':r[1],'before':json.loads(r[2]),'after':json.loads(r[3]),'reason':r[4]} for r in rows]

    def get(self, sid):
        with self.lock:
            row = self.conn.execute('SELECT data FROM sessions WHERE id=?', (sid,)).fetchone()
        if not row:
            raise KeyError(sid)
        data = json.loads(row[0])
        data['calls_used'] = self.calls_used(sid)
        return data

    def update(self, sid, **changes):
        with self.lock:
            data = self.get(sid)
            data.update(changes)
            return self.save(data)

    def event(self, sid, step, message, status='complete'):
        with self.lock:
            data = self.get(sid)
            data['events'].append({'step': step, 'status': status, 'message': message})
            data['events'] = data['events'][-50:]
            self.save(data)

    def calls_used(self, sid):
        with self.lock:
            return self.conn.execute('SELECT COUNT(*) FROM calls WHERE session_id=?', (sid,)).fetchone()[0]

    def reserve_call(self, sid, task='unknown', model=None):
        from .provider import ProviderFailure
        day = datetime.now(timezone.utc).date().isoformat()
        with self.lock, self.conn:
            self.conn.execute('BEGIN IMMEDIATE')
            for phase, start, cap in self.conn.execute('SELECT name,start_call_id,cap FROM phase_budgets'):
                if self.conn.execute('SELECT COUNT(*) FROM calls WHERE id>?', (start,)).fetchone()[0] >= cap:
                    raise ProviderFailure('phase_budget', f'Phase {phase} reached its total attempt ceiling. No further generation allowed.')
            daily = self.conn.execute('SELECT COUNT(*) FROM calls WHERE day=?', (day,)).fetchone()[0]
            if self.calls_used(sid) >= MAX_CALLS:
                raise ProviderFailure('run_budget', f'This run reached its {MAX_CALLS}-call safety cap. Export your saved progress; this run cannot make more calls.')
            research_exempt = self.research_phase == 'cross-product-v2' and self.conn.execute(
                'SELECT 1 FROM phase_budgets WHERE name=? AND cap=180', (self.research_phase,)).fetchone() is not None
            if daily >= MAX_DAILY_CALLS and not research_exempt:
                raise ProviderFailure('daily_budget', f'Local daily cap of {MAX_DAILY_CALLS} calls reached. Progress saved; resume after the next UTC day.')
            cursor = self.conn.execute('INSERT INTO calls(session_id,day,task,model,status,created_utc) VALUES (?,?,?,?,?,?)',
                (sid, day, task, model, 'reserved', datetime.now(timezone.utc).isoformat()))
            return cursor.lastrowid

    def finish_call(self, call_id, status, usage=None, error_code=None):
        # Only provider-reported integer counters and authored status codes are retained.
        names = ('prompt_token_count', 'candidates_token_count', 'thoughts_token_count',
                 'cached_content_token_count', 'total_token_count')
        safe_usage = {key: value for key, value in (usage or {}).items()
                      if key in names and isinstance(value, int) and not isinstance(value, bool) and value >= 0}
        with self.lock, self.conn:
            self.conn.execute('UPDATE calls SET status=?,usage=?,error_code=?,finished_utc=? WHERE id=?',
                (status, json.dumps(safe_usage), error_code, datetime.now(timezone.utc).isoformat(), call_id))

    def record_cache_hit(self, sid, task, model, origin_utc):
        with self.lock, self.conn:
            self.conn.execute('INSERT INTO cache_replays(session_id,task,model,created_utc,origin_utc) VALUES (?,?,?,?,?)',
                (sid, task, model, datetime.now(timezone.utc).isoformat(), origin_utc))

    def usage_summary(self, sid):
        with self.lock:
            records = self.conn.execute('SELECT task,model,status,usage,error_code,created_utc,finished_utc FROM calls WHERE session_id=? ORDER BY id', (sid,)).fetchall()
            hits = self.conn.execute('SELECT task,model,origin_utc FROM cache_replays WHERE session_id=? ORDER BY id', (sid,)).fetchall()
        calls = [{'task': row[0], 'model': row[1], 'status': row[2], 'usage': json.loads(row[3] or '{}'),
                  'error_code': row[4], 'started_utc': row[5], 'finished_utc': row[6]} for row in records]
        names = ('prompt_token_count', 'candidates_token_count', 'thoughts_token_count', 'total_token_count')
        known = {key: [c['usage'][key] for c in calls if key in c['usage']] for key in names}
        totals = {key: sum(values) if values else (None if calls else 0) for key, values in known.items()}
        return {'attempted_calls': len(calls), 'successful_calls': sum(c['status']=='success' for c in calls),
                'calls': calls, 'cache_replays': [{'task': h[0], 'model': h[1], 'original_utc': h[2]} for h in hits],
                'reported_token_totals': totals, 'calls_without_token_metadata': sum(not c['usage'] for c in calls),
                'calls_reporting_each_counter': {key: len(values) for key, values in known.items()},
                'usage_note': 'Provider counters, when supplied. Missing metadata is unknown, not zero. Attempts include errors and possible interrupted requests.'}

    def cache_get(self, key):
        with self.lock:
            row = self.conn.execute('SELECT data FROM cache WHERE key=?', (key,)).fetchone()
        return json.loads(row[0]) if row else None

    def cache_set(self, key, data):
        with self.lock, self.conn:
            self.conn.execute('INSERT OR REPLACE INTO cache VALUES (?,?)', (key, json.dumps(data)))

    def cache_delete(self, key):
        with self.lock, self.conn:
            self.conn.execute('DELETE FROM cache WHERE key=?', (key,))
