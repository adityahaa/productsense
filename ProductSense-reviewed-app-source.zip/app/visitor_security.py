"""Visitor ownership and bounded public-demo policy; separate from frozen generation."""
import hashlib,json,os,re,secrets,time,threading
from contextvars import ContextVar
from fastapi.responses import JSONResponse
visitor=ContextVar('productsense_visitor',default=None)
reservation=ContextVar('productsense_reservation',default=None)
COOKIE='productsense_visitor'

def install(app,store,workflow,public=False):
    ttl=int(os.getenv('PRODUCTSENSE_TTL_SECONDS','86400' if public else '2592000'))
    capacity=int(os.getenv('PRODUCTSENSE_CAPACITY','100' if public else '1000'))
    per_hour=int(os.getenv('PRODUCTSENSE_CREATES_PER_HOUR','10' if public else '120'))
    global_hour=int(os.getenv('PRODUCTSENSE_GLOBAL_CREATES_PER_HOUR','100' if public else '1000'))
    per_minute=int(os.getenv('PRODUCTSENSE_WRITES_PER_MINUTE','30' if public else '300'))
    global_minute=int(os.getenv('PRODUCTSENSE_GLOBAL_WRITES_PER_MINUTE','120' if public else '1000'))
    secure=public or os.getenv('PRODUCTSENSE_SECURE_COOKIE','false')=='true'
    with store.lock,store.conn:
        store.conn.execute('CREATE TABLE IF NOT EXISTS visitor_owners(sid TEXT PRIMARY KEY,owner TEXT NOT NULL,expires REAL NOT NULL)')
        store.conn.execute('CREATE TABLE IF NOT EXISTS visitor_creates(owner TEXT,stamp REAL)')
        store.conn.execute('CREATE TABLE IF NOT EXISTS visitor_writes(owner TEXT,stamp REAL)')
    def cleanup():
        now=time.time()
        expired=store.conn.execute('SELECT sid FROM visitor_owners WHERE expires<?',(now,)).fetchall()
        for (sid,) in expired:
            # Running work is bounded separately; defer until background completion.
            try:
                if store.get(sid).get('status')=='running':continue
            except KeyError:pass
            for table,column in [('document_versions','session_id'),('analysis_edits','session_id'),('sessions','id')]:
                store.conn.execute(f'DELETE FROM {table} WHERE {column}=?',(sid,))
            store.conn.execute('DELETE FROM visitor_owners WHERE sid=?',(sid,))
            # SqliteSaver owns its schema; delete only this expired visitor thread.
            with workflow.connection:
                for table in ['checkpoints','writes']:
                    if workflow.connection.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone():
                        workflow.connection.execute(f'DELETE FROM {table} WHERE thread_id=? OR thread_id LIKE ?',(sid,sid+':%'))
        store.conn.execute('DELETE FROM visitor_creates WHERE stamp<?',(now-3600,))
        store.conn.execute('DELETE FROM visitor_writes WHERE stamp<?',(now-60,))
    def own(sid):
        owner=visitor.get()
        if not owner:raise RuntimeError('Workspace creation requires visitor context')
        with store.lock,store.conn:
            pending=reservation.get()
            if pending:store.conn.execute('UPDATE visitor_owners SET sid=? WHERE sid=? AND owner=?',(sid,pending,owner))
            else:store.conn.execute('INSERT INTO visitor_owners VALUES (?,?,?)',(sid,owner,time.time()+ttl))
    app.state.assign_owner=own
    app.state.cleanup_visitors=cleanup
    @app.middleware('http')
    async def guard(request,call_next):
        path=request.url.path
        cookie=request.cookies.get(COOKIE,'')
        fresh=not re.fullmatch('[a-f0-9]{64}',cookie)
        if fresh:cookie=secrets.token_hex(32)
        owner=hashlib.sha256(cookie.encode()).hexdigest();token=visitor.set(owner);pending='pending-'+secrets.token_hex(16);rtoken=reservation.set(pending)
        def error(code,message):return JSONResponse({'detail':message},status_code=code)
        try:
            if request.headers.get('sec-fetch-site')=='cross-site' and path.startswith('/api/'):
                return error(403,'Cross-site access denied.')
            if request.method not in ('GET','HEAD','OPTIONS'):
                origin=request.headers.get('origin')
                if origin and origin!=str(request.base_url).rstrip('/'):
                    return error(403,'Cross-origin changes are disabled.')
                body=bytearray()
                async for chunk in request.stream():
                    body.extend(chunk)
                    if len(body)>125000:return error(413,'Request too large.')
                request._body=bytes(body)
                if body and 'application/json' in request.headers.get('content-type',''):
                    try:value=json.loads(body)
                    except (ValueError,UnicodeError):return error(400,'Invalid JSON.')
                    if not isinstance(value,dict):return error(422,'JSON body must be an object.')
                    if public and value.get('mode')=='gemini':return error(403,'Live AI is disabled in this saved demo.')
            if public and path=='/api/sessions/upload':return error(403,'Public saved demo accepts only its built-in sample; use local mode for CSV.')
            match=re.match(r'^/api/sessions/([^/]+)(?:/|$)',path)
            creating=path in ('/api/sessions/demo','/api/sessions/upload') and request.method=='POST'
            with store.lock,store.conn:
                cleanup()
                if request.method not in ('GET','HEAD','OPTIONS'):
                    if store.conn.execute('SELECT count(*) FROM visitor_writes').fetchone()[0]>=global_minute or store.conn.execute('SELECT count(*) FROM visitor_writes WHERE owner=?',(owner,)).fetchone()[0]>=per_minute:
                        r=error(429,'Workspace write rate limit reached.');r.headers['Retry-After']='60';return r
                    store.conn.execute('INSERT INTO visitor_writes VALUES (?,?)',(owner,time.time()))
                if match and not creating:
                    row=store.conn.execute('SELECT owner,expires FROM visitor_owners WHERE sid=?',(match[1],)).fetchone()
                    if not row or row[0]!=owner or row[1]<time.time():return error(404,'Workspace not found for this visitor.')
                if creating:
                    if store.conn.execute('SELECT count(*) FROM visitor_owners').fetchone()[0]>=capacity:return error(503,'Workspace capacity reached; retry after expiry.')
                    if store.conn.execute('SELECT count(*) FROM visitor_creates').fetchone()[0]>=global_hour or store.conn.execute('SELECT count(*) FROM visitor_creates WHERE owner=?',(owner,)).fetchone()[0]>=per_hour:
                        r=error(429,'Workspace creation rate limit reached.');r.headers['Retry-After']='3600';return r
                    # Include failed creation requests in the rate limit; no free bypass.
                    store.conn.execute('INSERT INTO visitor_creates VALUES (?,?)',(owner,time.time()))
                    store.conn.execute('INSERT INTO visitor_owners VALUES (?,?,?)',(pending,owner,time.time()+ttl))
            response=await call_next(request)
            if fresh:response.set_cookie(COOKIE,cookie,httponly=True,secure=secure,samesite='strict',max_age=ttl,path='/')
            return response
        finally:
            with store.lock,store.conn:store.conn.execute('DELETE FROM visitor_owners WHERE sid=?',(pending,))
            reservation.reset(rtoken);visitor.reset(token)
