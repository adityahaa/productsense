"""Offline authoring and conservative, inspectable document checks."""
import re
from io import BytesIO
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from .feedback import safe_url
from .evidence import references, requirements as requirement_records, acceptance_records, without_server_register

REQUIRED_SECTIONS = ['Problem statement', 'Target users', 'Goals', 'Non-goals',
    'Proposed success metrics', 'Requirements', 'User stories', 'Acceptance criteria',
    'Edge cases', 'Non-functional requirements', 'Dependencies', 'Risks',
    'Assumptions', 'Open questions', 'MVP scope']

SPECS = {
    'export': ('Diagram authors sharing drawings outside the editor',
        'a predictable export workflow that preserves the visible drawing',
        'Choose an export format, preview the result, and download the selected drawing.',
        'Given a drawing with text and shapes, when an author exports it in a supported format, then the downloaded file opens and contains the selected content.',
        'Given an unsupported format or a failed export, when export is attempted, then the editor shows an actionable error and preserves the drawing.'),
    'text': ('Diagram authors arranging labels and explanatory text',
        'a predictable text editing workflow with visible formatting controls',
        'Select a text element, change a supported text property, and retain that property when moving or reopening the drawing.',
        'Given a selected text element, when the author changes a supported property, then only that selection changes and the result remains after saving and reopening.',
        'Given an unavailable formatting action, when the author attempts it, then the editor explains the limitation without losing existing text.'),
    'sharing': ('Diagram authors and maintainers of self-hosted instances',
        'a clear sharing workflow with explicit editing and viewing permissions',
        'Create a supported sharing link with an explicit access mode and explain the prerequisites for the configured installation.',
        'Given a configured instance and a read-only link, when another browser opens it, then it loads the intended drawing and cannot modify it.',
        'Given missing collaboration configuration, when sharing is requested, then an actionable setup message appears without silently creating an empty drawing.'),
    'general': ('People reporting the selected problem; validate the actual segment',
        'a narrow improvement to the approved problem, pending discovery',
        'Document a reproducible example of the approved problem and implement the smallest validated user action that addresses it.',
        'Given the agreed reproduction case, when the supported action is completed, then the expected result documented in the test fixture occurs.',
        'Given missing or invalid input, when the action is attempted, then a readable recovery message appears and existing work is preserved.'),
}


def sample_prd(state):
    opportunity = next(x for x in state['opportunities'] if x['id'] == state['selected_opportunity_id'])
    title = opportunity['title']
    lower = title.lower()
    key = 'export' if any(w in lower for w in ('export', 'portability')) else 'text' if 'text' in lower else 'sharing' if any(w in lower for w in ('sharing', 'hosting', 'collaboration')) else 'general'
    user, solution, action, ac1, ac2 = SPECS[key]
    ids = opportunity['evidence_ids']
    refs = ' '.join(f'[{rid}]' for rid in ids)
    first = f'[{ids[0]}]'
    context = state['context']
    # Human input is preserved verbatim as explicitly attributed input, never treated as fact.
    corrections = state.get('corrections') or 'No corrections supplied. Assumptions still need validation.'
    evidence = '\n'.join(f"- [{r['id']}]({r['source_url']}) — {r['text']}" if r.get('source_url') else f"- [{r['id']}] — Uploaded row; no external source supplied. {r['text']}" for r in state['feedback'] if r['id'] in ids)
    return f'''# {context['product']} PRD — {title}

Saved sample / local template output. No model call was made. Proposed scope requires human review.

## Problem statement
Evidence (reported need, not independently verified current behaviour): {opportunity['problem']} {refs}

The evidence describes reported needs. Historical public issues may already be resolved; reproduce the problem in the current product before committing. The sample cannot establish affected customer numbers, revenue, market demand, or business impact.

## Target users
Assumption: {user}. Validate this segment with interviews and current product observation. Issue authors are not a representative customer sample.

## Goals
- Proposed direction: {solution}.
- User constraint — product goal: {context['goals']}
- Make the selected user action understandable and recoverable. Validate fit with the goal before implementation.

## Non-goals
- Rebuilding the entire product or addressing every feedback theme in this release.
- Promising revenue, retention, adoption, delivery dates, or engineering effort without evidence.
- Adding unrelated integrations, permissions or infrastructure without a separate decision.

## Proposed success metrics
- Proposal: measure successful completion of the selected action divided by attempts in an agreed usability test. Baseline and target: unknown; establish before release.
- Proposal: measure the rate of recoverable failures using consent-aware instrumentation. Baseline, target and observation window: to be agreed.
- Proposal: collect task-completion feedback from the validated user segment. No customer numbers are available in this sample.

## Requirements
- R1 — Evidence-informed problem / proposed solution: {action} {refs}
- R2 — Proposal: show a clear error and recovery action for invalid inputs or unsupported states; preserve existing work.
- R3 — Proposal: make the primary flow operable with keyboard controls, meaningful labels and visible focus.
- R4 — Assumption: preserve compatibility with existing saved drawings; confirm the actual format and support policy with engineering.

## User stories
- As a member of the proposed target segment, I want {solution}, so I can complete the intended task without an unexplained workaround. Problem evidence: {first}; the solution is a proposal.
- As a person encountering a failure, I want a useful recovery message so I can continue without losing my work. Proposal linked to R2.

## Acceptance criteria
- AC1 / R1 / Proposal: {ac1}
- AC2 / R2 / Proposal: {ac2}
- AC3 / R3 / Proposal: Given keyboard-only navigation, when the primary action is reached and activated, then every control has a visible focus state, a programmatic label, and no focus trap.
- AC4 / R4 / Assumption: Given an existing supported drawing fixture, when it is opened and saved through the new flow, then an automated comparison confirms its original content remains intact.
- AC5 / R1 / Proposal: Given a cancelled action, when the user returns to editing, then the prior drawing and selection remain available.

## Edge cases
- Empty and very large drawings; mixed scripts and unavailable fonts; unsupported or malformed input.
- Offline operation, repeated activation, cancellation, permissions mismatch and interrupted saving.
- Validate which cases apply to the selected opportunity; defer unrelated cases explicitly.

## Non-functional requirements
- Proposal: preserve user work on failure; avoid sensitive data in logs.
- Proposal: support keyboard and screen-reader use; verify with accessibility testing.
- Proposal: establish a performance baseline on an agreed reference drawing and device before setting a latency target.
- Assumption: use the product's existing browser support policy; confirm policy with the team.

## Dependencies
- Engineering discovery: current implementation, affected formats, existing tests and compatibility requirements.
- Design review of controls and recovery states. Team capacity supplied by the user: {context['capacity']}
- Deadline supplied by the user: {context['deadline']}. Feasibility is unestimated; this is not a delivery commitment.

## Risks
- Historical requests may describe functionality now available. Mitigation: inspect current behavior and issue resolution before scope approval.
- Small, selected public sample can misrepresent demand. Mitigation: validate with additional current evidence.
- Compatibility and accessibility regressions. Mitigation: test agreed fixtures and assistive workflows before release.
- Corrections may contradict the proposed scope. Resolve conflicts in human review before implementation.

## Assumptions
- {opportunity.get('assumptions', ['Current demand and feasibility remain unverified.'])[0]}
- The proposed solution is a starting point, not proven customer demand or an engineering estimate.
- User constraint — human corrections (verbatim, supplied by the approver; not customer evidence):

> {corrections.replace(chr(10), chr(10) + '> ')}

Treat these constraints as authoritative scope input after human review. Revise any generic proposal above that conflicts with them; this offline template cannot semantically reconcile arbitrary corrections.

## Open questions
- Can the team reproduce this problem in the current product? Which requests are already resolved?
- Who is affected today, in what context, and what workaround do they use?
- Which concrete user action and format belongs in the smallest release?
- What baseline, success target, capacity and delivery date can the team validate?
- Do the human corrections require removing or rewriting any requirement?

## MVP scope
- In: discover and reproduce the selected problem, validate one narrow proposed action, implement R1–R3 where applicable, and test the agreed acceptance cases.
- Conditional: R4 only after confirming compatibility requirements.
- Out: unrelated themes, unsupported business forecasts, and unvalidated expansion.
- Release gate: human approval of this edited PRD, current evidence verification and engineering feasibility review.

## Evidence register
{evidence}

Evidence is linked to the reported problem, not proof that the proposed requirements solve it.
'''


def review_prd(markdown, feedback):
    known = {r['id']: r for r in feedback}
    issues = []
    headings = {s.strip().lower() for s in re.findall(r'^##\s+(.+)$', markdown, re.M)}
    for section in REQUIRED_SECTIONS:
        if section.lower() not in headings:
            issues.append({'severity': 'error', 'message': f'Missing section: {section}.'})
    # Examine bracket markers even when followed by a Markdown URL.
    cited = {rid for rid, _ in references(markdown)}
    records = requirement_records(markdown)
    internal = {rid for rid in cited if re.fullmatch(r'R(?:EQ)?[- ]?\d+', rid) and rid not in known}
    for rid in sorted(internal - {rid for rid, _ in records}):
        issues.append({'severity': 'error', 'message': f'Broken requirement reference: {rid}.'})
    for rid in sorted(cited - set(known) - internal):
        issues.append({'severity': 'error', 'message': f'Unknown evidence ID: {rid}.'})
    for rid, url in references(markdown):
        if url and (not safe_url(url) or (rid in known and url != known[rid].get('source_url'))):
            issues.append({'severity': 'error', 'message': f'Unsafe or mismatched source link for {rid}.'})
    requirements = [line for _, line in records]
    covered = 0
    for line in requirements:
        refs = {rid for rid, _ in references(line)}
        if refs & known.keys() or re.search(r'\b(proposal|assumption|proposed|user constraint|user-supplied)\b', line, re.I):
            covered += 1
        else:
            issues.append({'severity': 'error', 'message': 'A requirement lacks a valid evidence ID or Proposal/Assumption/User constraint label: ' + line[:140]})
    if not requirements:
        issues.append({'severity': 'error', 'message': 'No R-numbered requirements detected.'})
    if not all(word in markdown.lower() for word in ('given', 'when', 'then')):
        issues.append({'severity': 'error', 'message': 'Add testable Given/When/Then acceptance criteria.'})
    criteria = acceptance_records(markdown)
    required_ids = {rid for rid, _ in records}
    criteria_links = {rid for ac in criteria if ac['given_when_then'] for rid in ac['requirement_ids']}
    missing_ac = sorted(required_ids - criteria_links)
    for rid in missing_ac:
        issues.append({'severity':'error','message':f'{rid} has no linked AC-numbered Given/When/Then acceptance criterion.'})
    for ac in criteria:
        if not ac['given_when_then'] or not ac['requirement_ids']:
            issues.append({'severity':'error','message':f"{ac['id']} needs a requirement ID and Given/When/Then outcome."})
        for rid in set(ac['requirement_ids']) - required_ids:
            issues.append({'severity':'error','message':f"{ac['id']} links an undefined requirement: {rid}."})
    # Narrow, explainable review flags; these are not semantic truth detection.
    section = ''
    for line in without_server_register(markdown).splitlines():
        if line.startswith('## '):
            section = line[3:].strip().lower()
        if not line.strip() or section in ('evidence register', 'source links (server-attached)'):
            continue
        uncertainty = bool(re.search(r'\b(unknown|unverified|not verified|not independently|not established|to be agreed|open question)\b',line,re.I))
        if re.search(r'\b(reasonable timeout|acceptable performance|sufficiently fast|fast|quickly|user.friendly|appropriate notification|trapped or logical)\b',line,re.I) and not uncertainty:
            issues.append({'severity':'error','message':'Vague acceptance/performance language: '+line[:160]+'. Define an observable outcome or an explicit unresolved measurement decision; do not invent a target.'})
        refs = {rid for rid, _ in references(line)} & known.keys()
        sources = [known[rid] for rid in refs] if refs else list(known.values())
        source_text = ' '.join(str(r.get('text',''))+' '+str(r.get('source_excerpt','')) for r in sources)
        local_label = bool(re.search(r'\b(assumption|proposal|proposed|user constraint|user-supplied)\b',line,re.I)) or section=='assumptions'
        if re.search(r'\bprint(?:ing)?\b',line,re.I) and not re.search(r'\bprint(?:ing)?\b',source_text,re.I) and not local_label:
            issues.append({'severity':'warning','message':'Printing-related inference is not explicit in its supplied evidence. Label it Assumption locally or remove it: '+line[:150]})
        if re.search(r'\b(currently (?:missing|unavailable|unsupported)|(?:does not|cannot|can.t) (?:support|export|print|color)|lacks? (?:PDF|export))\b',line,re.I) and not re.search(r'\b(historical|reported|report|requested|unknown|unverified|not verified|not independently|whether)\b',line,re.I) and not local_label:
            issues.append({'severity':'warning','message':'Possible unverified current-feature claim. Attribute it to the source report and state that current behaviour is unverified: '+line[:150]})
    for line in markdown.splitlines():
        if re.search(r'\b(proposal|target|proposed)\b',line,re.I) and re.search(r'\d+\s*(?:%|ms\b|seconds?\b|minutes?\b)|\b(?:zero|hundred|thousand)\b',line,re.I) and not re.search(r'unknown|unmeasured|not set|undecided',line,re.I):
            issues.append({'severity':'warning','message':'Numeric target requires supplied evidence or explicit user authorization, even when labelled a proposal: '+line[:160]})
        if re.search(r'(\d+\s*%|[₹$€£]\s*\d|\b\d+\s+(customers|users|hours|days|weeks|engineers)\b)', line, re.I) and not re.search(r'proposal|assumption|proposed|target|unknown|unmeasured|user-supplied', line, re.I):
            issues.append({'severity': 'warning', 'message': 'Numeric claim needs human evidence review: ' + line[:160]})
    issues.append({'severity': 'warning', 'message': 'Automated checks validate structure and citation IDs only. A human must check relevance, current evidence, feasibility, corrections and factual claims.'})
    for ids,kind in [([r for r,_ in records],'requirement'),([a['id'] for a in criteria],'acceptance criterion')]:
        if len(ids)!=len(set(ids)):issues.append({'severity':'error','message':f'Duplicate {kind} IDs detected. Keep stable unique identifiers.'})
    return {'issues': issues[:30], 'evidence_coverage': round(covered / len(requirements), 3) if requirements else 0,
            'requirements_count': len(requirements), 'valid_evidence_ids': sorted(cited & known.keys()), 'human_reviewed': False,
            'acceptance_criteria_count':len(criteria), 'requirements_with_acceptance':len(required_ids & criteria_links),
            'requirements_missing_acceptance':missing_ac,
            'acceptance_links':[{'id':ac['id'],'requirement_ids':ac['requirement_ids'],'given_when_then':ac['given_when_then']} for ac in criteria]}


def docx_export(markdown):
    doc = Document()
    section = doc.sections[0]
    section.top_margin = section.bottom_margin = Inches(.75)
    normal = doc.styles['Normal']
    normal.font.name, normal.font.size = 'Calibri', Pt(11)
    normal.paragraph_format.space_after = Pt(7)
    for style in ('Title', 'Heading 1', 'Heading 2', 'Heading 3'):
        doc.styles[style].font.color.rgb = RGBColor(0, 0, 0)

    def inline(p, text):
        for part in re.split(r'(\[[^\]]+\]\([^)]+\))', text):
            match = re.fullmatch(r'\[([^\]]+)\]\(([^)]+)\)', part)
            if match and safe_url(match[2]):
                link = OxmlElement('w:hyperlink')
                link.set(qn('r:id'), p.part.relate_to(match[2], 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink', is_external=True))
                run, props, txt = OxmlElement('w:r'), OxmlElement('w:rPr'), OxmlElement('w:t')
                color = OxmlElement('w:color'); color.set(qn('w:val'), '155653'); props.append(color)
                txt.text = match[1]; run.append(props); run.append(txt); link.append(run); p._p.append(link)
            else:
                p.add_run(part)

    for line in markdown.splitlines():
        if not line.strip():
            continue
        heading = re.match(r'^(#{1,4})\s+(.*)', line)
        if heading:
            p = doc.add_paragraph(style='Title' if len(heading[1]) == 1 else f'Heading {min(len(heading[1])-1, 3)}')
            inline(p, heading[2])
        else:
            bullet = re.match(r'^[-*]\s+(.*)', line)
            p = doc.add_paragraph(style='List Bullet' if bullet else 'Normal')
            inline(p, bullet[1] if bullet else line.lstrip('> '))
    out = BytesIO()
    doc.save(out)
    return out.getvalue()
