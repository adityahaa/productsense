from typing import Literal
from pydantic import BaseModel, Field, ConfigDict

class ProductContext(BaseModel):
    model_config = ConfigDict(extra='forbid')
    product: str = Field(default='Excalidraw', min_length=1, max_length=120)
    goals: str = Field(default='Make everyday diagram editing more predictable and accessible.', min_length=1, max_length=1500)
    deadline: str = Field(default='Not set — agree with the team', max_length=120)
    capacity: str = Field(default='Not estimated — validate with engineering', max_length=500)

class SessionInput(BaseModel):
    context: ProductContext = Field(default_factory=ProductContext)
    mode: Literal['demo', 'gemini'] = 'demo'
    public_data_confirmed: bool = False

class Approval(BaseModel):
    opportunity_id: str = Field(min_length=1, max_length=80)
    corrections: str = Field(default='', max_length=2000)
    clarification: str = Field(default='Unknown — current behaviour and acceptance fixtures require validation.', max_length=1000)

class PRDEdit(BaseModel):
    markdown: str = Field(min_length=20, max_length=40000)
    actor: Literal['manual','assistant'] = 'manual'
    scope_change: bool = False
    scope_approved: bool = False

class Group(BaseModel):
    title: str = Field(max_length=120)
    problem: str = Field(max_length=1000)
    evidence_ids: list[str] = Field(min_length=1, max_length=30)
    assumptions: list[str] = Field(default_factory=list, max_length=8)

class AnalysisOutput(BaseModel):
    groups: list[Group] = Field(min_length=1, max_length=8)

class DraftOutput(BaseModel):
    markdown: str = Field(min_length=100, max_length=40000)

class ReviewIssue(BaseModel):
    severity: Literal['warning', 'error'] = 'warning'
    message: str = Field(max_length=800)

class ReviewOutput(BaseModel):
    issues: list[ReviewIssue] = Field(default_factory=list, max_length=12)
