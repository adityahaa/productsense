import json
import os
import threading
import uuid
from pathlib import Path
from urllib.parse import urlsplit
from contextlib import asynccontextmanager
from fastapi import FastAPI, BackgroundTasks, HTTPException, UploadFile, File, Form, Request
from fastapi.responses import FileResponse, Response, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import ValidationError
from .config import ROOT, MAX_ROWS, MAX_FILE_BYTES, MAX_CALLS, MAX_DAILY_CALLS, gemini_ready, provider_settings
from .models import SessionInput, ProductContext, Approval, PRDEdit
from .feedback import parse_csv
from .store import Store
from .workflow import Workflow
from .prd import review_prd, docx_export
from .changes import install_changes, enrich
from .analysis import scope_checks


def create_app(data_dir: Path | None = None, *, public_demo: bool = False, services=None):
    path = Path(data_dir or os.getenv('PRODUCTSENSE_DATA_DIR') or ROOT / 'runtime')
    store = services.store if services else Store(path)
    workflow = services.workflow if services else Workflow(store, path)
    mutation_lock = threading.RLock()

    @asynccontextmanager
    async def lifespan(app):
        yield
        if not services:
            workflow.connection.close()
            store.conn.close()

    app = FastAPI(title='ProductSense', version='1.0.0', lifespan=lifespan)
    app.state.store, app.state.workflow = store, workflow
    app.state.queue_operation = services.queue if services else None

    @app.middleware('http')
    async def security(request: Request, call_next):
        # No accounts: same-origin mutations only; local default binds loopback.
        origin = request.headers.get('origin')
        if request.method in ('POST', 'PUT', 'PATCH', 'DELETE') and origin and urlsplit(origin).netloc != request.headers.get('host'):
            return JSONResponse({'detail': 'Cross-origin changes are disabled.'}, status_code=403)
        if request.method in ('POST', 'PUT', 'PATCH'):
            try:
                if int(request.headers.get('content-length', 0)) > MAX_FILE_BYTES + 25000:
                    return JSONResponse({'detail': 'Request too large. Start with a small CSV sample.'}, status_code=413)
            except ValueError:
                return JSONResponse({'detail': 'Invalid content length.'}, status_code=400)
            # Enforce the same bound for chunked requests with no Content-Length.
            body = bytearray()
            async for chunk in request.stream():
                body.extend(chunk)
                if len(body) > MAX_FILE_BYTES + 25000:
                    return JSONResponse({'detail': 'Request too large. Start with a small CSV sample.'}, status_code=413)
            request._body = bytes(body)
        response = await call_next(request)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'no-referrer'
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        if request.url.path.startswith('/api/'):
            response.headers['Cache-Control'] = 'no-store'
        return response

    def get(sid):
        try:
            return enrich(store.get(sid))
        except KeyError:
            raise HTTPException(404, 'Workspace not found.') from None

    def new(feedback, payload, public_demo=False):
        data = {'id': str(uuid.uuid4()), 'status': 'new', 'mode': payload.mode, 'context': payload.context.model_dump(),
            'feedback': feedback, 'opportunities': [], 'groups': [], 'selected_opportunity_id': None,
            'corrections': '', 'prd_markdown': '', 'public_data_confirmed':public_demo or payload.public_data_confirmed, 'review': {'issues': [], 'evidence_coverage': 0, 'requirements_count': 0},
            'events': [], 'error': None, 'calls_used': 0, 'revision_count': 0,
            'sample_label': 'Saved public demo • historical Excalidraw issues • no AI call' if payload.mode == 'demo' and public_demo else 'Local heuristic and template • no AI call' if payload.mode == 'demo' else 'Gemini live • public data only'}
        store.save(data)
        app.state.assign_owner(data['id'])
        return data

    @app.get('/api/config')
    def config():
        return {'public_demo': public_demo, 'gemini_ready': False if public_demo else gemini_ready(), 'model': provider_settings()['model'],
                'limits': {'max_rows': MAX_ROWS, 'max_file_bytes': MAX_FILE_BYTES, 'max_calls_per_run': MAX_CALLS, 'max_daily_calls': MAX_DAILY_CALLS},
                'demo_label': 'Saved public demo / local template. No AI call. Historical issues may be resolved.'}

    @app.get('/api/example.csv')
    def example_csv():
        return FileResponse(ROOT / 'data/demo_feedback.csv', media_type='text/csv', filename='productsense-example.csv')

    @app.get('/api/health')
    def health():
        return {'status': 'ok'}

    @app.post('/api/sessions/demo', status_code=201)
    def demo(payload: SessionInput):
        return new(json.loads((ROOT / 'data/demo_feedback.json').read_text(encoding='utf-8')), payload, True)

    @app.post('/api/sessions/upload', status_code=201)
    async def upload(file: UploadFile = File(...), context: str = Form('{}'), mode: str = Form('demo')):
        try:
            data = await file.read(MAX_FILE_BYTES + 1)
            payload = SessionInput(context=ProductContext.model_validate_json(context), mode=mode)
            return new(parse_csv(data), payload)
        except (ValueError, ValidationError) as exc:
            # Pydantic errors can echo inputs: only safe authored validation messages.
            if isinstance(exc, ValidationError):
                raise HTTPException(422, 'Invalid product context or mode. Check field lengths and choose demo or gemini.') from None
            raise HTTPException(400, str(exc)) from None
        finally:
            await file.close()

    @app.get('/api/sessions/{sid}')
    def session(sid: str):
        return get(sid)

    @app.patch('/api/sessions/{sid}/context')
    def context(sid: str, payload: SessionInput):
        with mutation_lock:
            current = get(sid)
            if current['status'] != 'new':
                raise HTTPException(409, 'Context is locked after analysis; start a new workspace to change it.')
            label = current['sample_label'] if payload.mode == current['mode'] else ('Local heuristic and template • no AI call' if payload.mode == 'demo' else 'Gemini live • public data only')
            return store.update(sid, context=payload.context.model_dump(), mode=payload.mode, sample_label=label,public_data_confirmed=payload.public_data_confirmed or current.get('public_data_confirmed',False))

    def schedule(sid, tasks, operation, decision=None):
        store.update(sid, status='running', error=None)
        if services:
            services.queue(sid, operation, decision)
        else:
            tasks.add_task(workflow.run, sid, operation, decision)
        return get(sid)

    @app.post('/api/sessions/{sid}/analyze', status_code=202)
    def analyze(sid: str, tasks: BackgroundTasks):
        with mutation_lock:
            if get(sid)['status'] != 'new':
                raise HTTPException(409, 'This workspace was already analyzed. Resume a paused run or create a new workspace.')
            if get(sid)['mode']=='gemini' and not get(sid).get('public_data_confirmed'):
                raise HTTPException(400,'Confirm this workspace contains only public, non-sensitive data before live analysis. Otherwise use local demo mode.')
            return schedule(sid, tasks, 'start')

    @app.post('/api/sessions/{sid}/approve', status_code=202)
    def approve(sid: str, payload: Approval, tasks: BackgroundTasks):
        with mutation_lock:
            current = get(sid)
            if current['status'] != 'awaiting_approval':
                raise HTTPException(409, 'Analyze feedback and wait for the approval checkpoint first.')
            if payload.opportunity_id not in {o['id'] for o in current['opportunities']}:
                raise HTTPException(400, 'Choose an opportunity from this workspace.')
            return schedule(sid, tasks, 'approve', payload.model_dump())

    @app.post('/api/sessions/{sid}/resume', status_code=202)
    def resume(sid: str, tasks: BackgroundTasks):
        with mutation_lock:
            current = get(sid)
            if current['status'] not in ('paused', 'error'):
                raise HTTPException(409, 'Only paused or failed workspaces can resume.')
            if current.get('pending_revision',{}).get('status') in ('paused','running'):
                store.update(sid,status='running',error=None)
                if services:
                    services.queue(sid, 'revision_resume')
                else:
                    tasks.add_task(app.state.run_revision,sid,True)
                return get(sid)
            return schedule(sid, tasks, 'resume')

    @app.patch('/api/sessions/{sid}/prd')
    def edit(sid: str, payload: PRDEdit):
        with mutation_lock:
            current = get(sid)
            if current['status'] != 'complete':
                raise HTTPException(409, 'Finish generation before editing the PRD.')
            if current.get('pending_revision',{}).get('status') in ('awaiting_approval','running','paused'):
                raise HTTPException(409,'Apply or cancel the pending revision before editing its base document.')
            from .changes import split_sections
            try:
                old=split_sections(current['prd_markdown']);new=split_sections(payload.markdown)
            except ValueError as exc:
                raise HTTPException(400,str(exc)) from None
            scope_changed=payload.scope_change
            for h in ('Requirements','Goals','Non-goals','MVP scope'):
                before=current['prd_markdown'][slice(*old[h])].strip() if h in old else ''
                after=payload.markdown[slice(*new[h])].strip() if h in new else ''
                scope_changed=scope_changed or before!=after
            if scope_changed and not payload.scope_approved:
                raise HTTPException(409,'Scope-related sections changed. Confirm renewed scope approval before saving; your editor text is preserved.')
            review = review_prd(payload.markdown, current['feedback'])
            selected=next((o for o in current['opportunities'] if o['id']==current.get('selected_opportunity_id')), {})
            review['issues']+=scope_checks(payload.markdown,{'excluded':selected.get('scope_excluded','')})
            store.event(sid, 'Editor save', 'PRD saved. Structural checks rerun; previous model review no longer applies. Saving does not record human quality approval.')
            return store.update(sid, prd_markdown=payload.markdown, review=review,version_origin=payload.actor,
                latest_scope_approval={'approved':payload.scope_approved,'changed':scope_changed})

    @app.get('/api/sessions/{sid}/export')
    def export(sid: str, format: str = 'md', include_review: bool = False):
        current = get(sid)
        if not current['prd_markdown']:
            raise HTTPException(409, 'Approve an opportunity and generate a PRD first.')
        if format not in ('md', 'docx'):
            raise HTTPException(400, 'Choose md or docx.')
        markdown=current['prd_markdown']
        if include_review:
            markdown+='\n\n## Traceability and unresolved review\n'
            markdown+='Document origin: '+current.get('version_origin','legacy / unknown')+'. Human quality approval remains pending.\n'
            if current.get('downstream_needs_review'):markdown+='Analysis changed after this PRD; renewed scope approval and document review required.\n'
            for link in current['review'].get('acceptance_links',[]):
                markdown+=f"- {link['id']} → {', '.join(link['requirement_ids'])}; shape check only.\n"
            for issue in current['review'].get('issues',[]):markdown+='- '+issue['severity']+': '+issue['message']+'\n'
        content = markdown.encode('utf-8') if format == 'md' else docx_export(markdown)
        media = 'text/markdown; charset=utf-8' if format == 'md' else 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        return Response(content=content, media_type=media, headers={'Content-Disposition': f'attachment; filename="productsense-prd.{format}"'})

    @app.get('/api/sessions/{sid}/backup')
    def backup(sid: str):
        return Response(json.dumps({**get(sid),'document_versions':store.versions(sid),'analysis_history':store.analysis_history(sid)}, indent=2, ensure_ascii=False).encode(), media_type='application/json',
                        headers={'Content-Disposition': 'attachment; filename="productsense-workspace.json"'})

    install_changes(app,store,workflow,get,mutation_lock)
    app.mount('/static', StaticFiles(directory=ROOT / 'static'), name='static')

    @app.get('/')
    def index():
        return FileResponse(ROOT / 'static/index.html')

    if services:
        services.install(app)
    else:
        from .visitor_security import install
        install(app,store,workflow,public_demo)
    return app


# The Vercel entrypoint constructs cloud services lazily; never open local SQLite there.
app = None if os.getenv('PRODUCTSENSE_CLOUD') == 'true' else create_app()
