"""Public saved-demo process. No credentials or research/review routes."""
import os
os.environ['GEMINI_FREE_TIER_CONFIRMED']='false'
os.environ['GEMINI_PUBLIC_DATA_CONFIRMED']='false'
os.environ['GEMINI_API_KEY']=''
from .main import create_app
app=create_app(public_demo=True)
