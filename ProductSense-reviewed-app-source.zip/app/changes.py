"""Editable analysis and scoped, explicitly approved revision checkpoints."""
import json
import re
import uuid
from typing import Literal, TypedDict
from fastapi import HTTPException, BackgroundTasks
from pydantic import BaseModel, Field, ConfigDict
from langgraph.graph import StateGraph, START, END
from langgraph.types import interrupt, Command
from .analysis import prioritize_groups, duplicates, opportunity_details, scope_checks
from .prd import review_prd, REQUIRED_SECTIONS
from .provider import ProviderFailure
from .evidence import requirements, acceptance_records


class Relation(BaseModel):
    source_id: str = Field(max_length=64)
    quote: str = Field(min_length=1,max_length=1200)
    kind: Literal['conflict','different_preference','tradeoff','support']
    judgement: Literal['unassessed','supported','partial','unsupported','uncertain'] = 'unassessed'
    explanation: str = Field(default='Needs review',max_length=800)


class EditableGroup(BaseModel):
    id: str = Field(pattern=r'^[A-Za-z0-9_-]{1,80}$')
    title: str = Field(min_length=1,max_length=120)
    problem: str = Field(min_length=1,max_length=1000)
    evidence_ids: list[str] = Field(min_length=1,max_length=30)
    assumptions: list[str] = Field(default_factory=list,max_length=8)
    scope_included: str = Field(default='Unknown — clarify before delivery',max_length=1000)
    scope_excluded: str = Field(default='',max_length=1000)
    recommendation: Literal['Build','Investigate','Defer'] = 'Investigate'
    recommendation_reason: str = Field(default='Current evidence and feasibility require validation.',max_length=1000)
    relations: list[Relation] = Field(default_factory=list,max_length=30)


class AnalysisEdit(BaseModel):
    groups: list[EditableGroup] = Field(min_length=1,max_length=8)
    expected_revision: int = 0
    reason: str = Field(min_length=1,max_length=1000)


class SectionChange(BaseModel):
    heading: str = Field(max_length=120)
    body: str = Field(min_length=1,max_length=15000)


class SectionOutput(BaseModel):
    sections: list[SectionChange] = Field(min_length=1,max_length=5)


class RevisionRequest(BaseModel):
    sections: list[str] = Field(min_length=1,max_length=5)
    request: str = Field(min_length=5,max_length=2000)
    replacement: str = Field(default='',max_length=15000)
    scope_change: bool = False
    actor: Literal['manual','assistant'] = 'manual'


class RevisionApproval(BaseModel):
    approve: bool
    scope_approved: bool = False


def split_sections(markdown):
    matches=list(re.finditer(r'^## (.+)$',markdown,re.M));result={}
    for i,m in enumerate(matches):
        if m[1] in result:raise ValueError('Duplicate section headings must be resolved before scoped revision.')
        end=matches[i+1].start() if i+1<len(matches) else len(markdown)
        result[m[1]]=(m.start(),end)
    return result


def apply_sections(markdown,changes,allowed):
    sections=split_sections(markdown)
    names=[c['heading'] for c in changes]
    if set(names)!=set(allowed) or len(names)!=len(set(names)):
        raise ProviderFailure('revision_scope','Revision did not return exactly the approved sections. Original preserved.')
    for c in sorted(changes,key=lambda c:sections[c['heading']][0],reverse=True):
        if re.search(r'^#{1,2} ',c['body'],re.M):raise ProviderFailure('revision_scope','Section body contains a document heading. Original preserved.')
        start,end=sections[c['heading']]
        markdown=markdown[:start]+'## '+c['heading']+'\n'+c['body'].rstrip()+'\n\n'+markdown[end:]
    if len(markdown)>40000:raise ProviderFailure('revision_scope','Revision exceeds document size cap. Original preserved.')
    return markdown


def enrich(session):
    for op in session.get('opportunities',[]):
        op['details']=opportunity_details(op,session['feedback'],session['context'])
    session['duplicate_candidates']=duplicates(session['feedback'])
    session.setdefault('analysis_revision',0)
    return session


def install_changes(app,store,workflow,get,lock):
    def gate(state):
        choice=interrupt({'revision':state['plan'],'message':'Approve this scoped revision. Scope changes need renewed approval.'})
        return {**state,'approved':choice}

    def revise(state):
        sid=state['id'];current=store.get(sid); plan=state['plan'];base=state['base']
        if current['mode']=='demo':
            changes=[{'heading':plan['sections'][0],'body':plan['replacement']}]
        else:
            output=workflow.provider.generate(sid,'targeted_revision',{
                **workflow.payload(current),'markdown':base,'approved_sections':plan['sections'],
                'change_request':plan['request'],'required_ids':[r for r,_ in requirements(base)]},SectionOutput)
            changes=output['sections']
        result=apply_sections(base,changes,plan['sections'])
        if current['mode']=='gemini' and not {r for r,_ in requirements(base)}<={r for r,_ in requirements(result)}:
            raise ProviderFailure('revision_ids','Model removed or renamed existing requirement IDs. Original preserved; edit explicitly instead.')
        if current['mode']=='gemini' and not {a['id'] for a in acceptance_records(base)}<={a['id'] for a in acceptance_records(result)}:
            raise ProviderFailure('revision_ids','Model removed or renamed acceptance criterion IDs. Original preserved; edit explicitly instead.')
        return {**state,'result':result}

    graph=StateGraph(dict);graph.add_node('approval',gate);graph.add_node('revision',revise)
    graph.add_edge(START,'approval');graph.add_edge('approval','revision');graph.add_edge('revision',END)
    revision_graph=graph.compile(checkpointer=workflow.saver)

    def rconfig(sid,pid):return {'configurable':{'thread_id':sid+':revision:'+pid},'recursion_limit':5}

    def run_revision(sid,resume=False):
        current=store.get(sid);plan=current['pending_revision'];config=rconfig(sid,plan['id'])
        try:
            result=revision_graph.invoke(None if resume else Command(resume={'approved':True,'scope_approved':plan['scope_approved']}),config)
            review=review_prd(result['result'],current['feedback'])
            selected=next((o for o in current['opportunities'] if o['id']==current.get('selected_opportunity_id')), {})
            review['issues']+=scope_checks(result['result'],{'excluded':selected.get('scope_excluded','')})
            store.update(sid,prd_markdown=result['result'],version_origin='model-scoped-revision' if current['mode']=='gemini' else plan['actor']+'-scoped-edit',
                review=review,status='complete',pending_revision={**plan,'status':'applied'},error=None)
            store.event(sid,'Scoped revision','Approved sections changed; other sections preserved. Deterministic review rerun; human review pending.')
        except ProviderFailure as exc:
            store.update(sid,status='paused',pending_revision={**plan,'status':'paused'},error={'code':exc.code,'message':exc.message})
        except Exception:
            store.update(sid,status='paused',pending_revision={**plan,'status':'paused'},error={'code':'revision_error','message':'Scoped revision stopped. Original document and checkpoint preserved.'})

    app.state.run_revision=run_revision

    @app.patch('/api/sessions/{sid}/analysis')
    def edit_analysis(sid:str,payload:AnalysisEdit):
        with lock:
            current=get(sid)
            if current['status'] not in ('awaiting_approval','complete') or current.get('pending_revision',{}).get('status') in ('awaiting_approval','running','paused'):
                raise HTTPException(409,'Finish the current operation before editing analysis.')
            if payload.expected_revision!=current.get('analysis_revision',0):raise HTTPException(409,'Analysis changed; reload before saving your edits.')
            groups=[g.model_dump() for g in payload.groups];ids=[i for g in groups for i in g['evidence_ids']];known={r['id']:r for r in current['feedback']}
            if set(ids)!=set(known) or len(ids)!=len(set(ids)) or len({g['id'] for g in groups})!=len(groups):raise HTTPException(400,'Assign every feedback row exactly once and use unique group IDs.')
            for group in groups:
                for relation in group['relations']:
                    row=known.get(relation['source_id'])
                    if not row or not (relation['quote'] in row['text'] or relation['quote'] in row.get('source_excerpt','')):
                        raise HTTPException(400,'A relation quote does not exactly match its supplied source. No edits saved.')
            opportunities=prioritize_groups(groups,current['feedback'],current['context'])
            # Re-enter the existing graph's real approval interrupt. Existing PRD remains intact.
            config=workflow.config(sid)
            workflow.graph.update_state(config,{'groups':groups,'opportunities':opportunities},as_node='prioritize')
            workflow.graph.invoke(None,config)
            store.audit_analysis(sid,current['opportunities'],opportunities,payload.reason)
            store.update(sid,groups=groups,opportunities=opportunities,status='awaiting_approval',
                analysis_revision=current.get('analysis_revision',0)+1,downstream_needs_review=bool(current['prd_markdown']))
            store.event(sid,'Analysis edit','Group membership/scope/recommendations saved. Existing PRD preserved; renewed approval required before generation.')
            return enrich(store.get(sid))

    @app.get('/api/sessions/{sid}/history')
    def history(sid:str):
        current=get(sid)
        # Preserve pre-upgrade documents on first history access as legacy snapshots.
        if current['prd_markdown'] and not store.versions(sid):store.save(current)
        return {'versions':store.versions(sid),'analysis_edits':store.analysis_history(sid)}

    @app.post('/api/sessions/{sid}/revision')
    def request_revision(sid:str,payload:RevisionRequest):
        with lock:
            current=get(sid)
            if current['status']!='complete' or current.get('downstream_needs_review') or current.get('pending_revision',{}).get('status') in ('awaiting_approval','running','paused'):
                raise HTTPException(409,'Complete/approve current work before requesting another revision.')
            try: headings=split_sections(current['prd_markdown'])
            except ValueError as exc:raise HTTPException(400,str(exc)) from None
            if len(set(payload.sections))!=len(payload.sections) or any(h not in headings or h not in REQUIRED_SECTIONS for h in payload.sections):raise HTTPException(400,'Select unique existing PRD sections, excluding the source register.')
            if current['mode']=='demo' and (len(payload.sections)!=1 or not payload.replacement.strip()):raise HTTPException(400,'Offline mode needs replacement text for one selected section; no AI is used.')
            plan={**payload.model_dump(),'id':str(uuid.uuid4()),'status':'awaiting_approval','scope_approved':False}
            plan['scope_change']=payload.scope_change or bool(set(payload.sections)&{'Requirements','Goals','Non-goals','MVP scope'})
            plan['affected']={'sections':payload.sections,'requirement_ids':[r for r,_ in requirements(current['prd_markdown'])],
                'acceptance_ids':[a['id'] for a in acceptance_records(current['prd_markdown'])],
                'review_dependencies':['Acceptance criteria','Risks','MVP scope'],'note':'Conservative dependency candidates; inspect diff. Semantic impact is not guaranteed.'}
            revision_graph.invoke({'id':sid,'base':current['prd_markdown'],'plan':plan},rconfig(sid,plan['id']))
            return enrich(store.update(sid,pending_revision=plan))

    @app.post('/api/sessions/{sid}/revision/approve',status_code=202)
    def approve_revision(sid:str,payload:RevisionApproval,tasks:BackgroundTasks):
        with lock:
            current=get(sid);plan=current.get('pending_revision',{})
            if plan.get('status')!='awaiting_approval' or not payload.approve:raise HTTPException(409,'A pending revision needs explicit approval.')
            if plan['scope_change'] and not payload.scope_approved:raise HTTPException(409,'This changes approved scope; renewed scope approval is required.')
            store.update(sid,pending_revision={**plan,'status':'running','scope_approved':payload.scope_approved},status='running')
            if app.state.queue_operation:
                app.state.queue_operation(sid,'revision')
            else:
                tasks.add_task(run_revision,sid)
            return enrich(store.get(sid))

    @app.post('/api/sessions/{sid}/revision/cancel')
    def cancel_revision(sid:str):
        with lock:
            current=get(sid);plan=current.get('pending_revision',{})
            if plan.get('status') not in ('awaiting_approval','paused'):raise HTTPException(409,'Only pending or paused revisions can be cancelled.')
            return enrich(store.update(sid,pending_revision={**plan,'status':'cancelled'},status='complete',error=None))
