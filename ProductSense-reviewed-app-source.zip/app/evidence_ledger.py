"""Deterministic evidence-first ledger built BEFORE drafting.

Separates: observed reports (with historical status), user constraints (not evidence), open questions, and
candidate duplicates/conflicts/mixed-source warnings. All candidates are lexical aids for inspection; none is a
semantic verdict, and no row is removed or merged. Proposals are intentionally empty: they do not exist yet.
Compact by design (IDs and metadata; raw text stays in `feedback`) to avoid inflating model input."""
import re
from .analysis import duplicates, words

ADD = {'add', 'enable', 'allow', 'support', 'show', 'keep', 'default', 'always'}
REMOVE = {'remove', 'disable', 'disallow', 'hide', 'stop', 'never', 'without', 'drop', 'deprecate'}
SHORT_WORDS = 8


def source_key(url):
    m = re.match(r'https?://github\.com/([^/]+/[^/]+)/', url or '')
    if m:
        return m[1].lower()
    m = re.match(r'https?://([^/]+)/', url or '')
    return m[1].lower() if m else 'no-source-url'


def conflict_candidates(rows):
    out = []
    for i, a in enumerate(rows):
        for b in rows[i + 1:]:
            wa, wb = set(re.findall(r"[a-z']{3,}", a['text'].lower())), set(re.findall(r"[a-z']{3,}", b['text'].lower()))
            topic_a, topic_b = words(a['text']) - ADD - REMOVE, words(b['text']) - ADD - REMOVE
            if not topic_a or not topic_b or len(topic_a & topic_b) / len(topic_a | topic_b) < .25:
                continue
            if (wa & ADD and not wa & REMOVE and wb & REMOVE and not wb & ADD) or (wb & ADD and not wb & REMOVE and wa & REMOVE and not wa & ADD):
                out.append({'ids': [a['id'], b['id']], 'reason': 'Opposite request cues on a shared topic; candidate conflict only, may be compatible in different contexts.'})
    return out


def build_ledger(payload):
    rows = payload.get('feedback', [])
    opp = payload.get('opportunity', {}) or {}
    ctx = payload.get('context', {}) or {}
    clar = str(payload.get('clarification', 'Unknown'))
    by_source = {}
    for r in rows:
        by_source.setdefault(source_key(r.get('source_url', '')), []).append(r['id'])
    short = [r['id'] for r in rows if len(r['text'].split()) < SHORT_WORDS]
    questions = []
    if clar.lower().startswith('unknown'):
        questions.append('Clarification not provided: current behaviour and acceptance fixtures must be validated, not assumed.')
    questions += [f'{i}: very short report; the intended problem cannot be established without clarification.' for i in short]
    warnings = []
    if len(by_source) > 1:
        warnings.append({'code': 'multiple_sources', 'message': 'Rows come from more than one source project; check they describe one product problem.', 'sources': by_source})
    if any('closed' in str(r.get('source_status', '')).lower() or 'closed' in str(r.get('source_state', '')).lower() for r in rows):
        warnings.append({'code': 'closed_reports', 'message': 'Some reports are closed; they may already be resolved. Describe them as historical.'})
    return {
        'observed_reports': [{'id': r['id'], 'source_url': r.get('source_url', ''),
                              'source_status': r.get('source_status') or r.get('source_state') or 'Unknown',
                              'note': 'Historical report; not proof of current behaviour.'} for r in rows],
        'user_constraints': {'goals': ctx.get('goals'), 'scope_included': opp.get('scope_included'), 'scope_excluded': opp.get('scope_excluded'),
                             'corrections': payload.get('corrections', ''), 'note': 'User constraints are human input, not customer evidence.'},
        'duplicate_candidates': duplicates(rows), 'conflict_candidates': conflict_candidates(rows),
        'very_short_reports': short, 'open_questions': questions, 'warnings': warnings,
        'proposals': [], 'proposals_note': 'None exist before drafting; every proposal in the PRD must be labelled Proposal.',
    }
