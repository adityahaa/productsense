"""Citation syntax helpers; citation existence does not prove claim support."""
import re


def references(markdown):
    """Yield individual IDs from [ID] or [ID, ID], with an optional URL."""
    for match in re.finditer(r'\[([^\]\n]+)\](?:\(([^)\n]+)\))?', markdown):
        if not match[2] and match[1].strip().lower() in {'assumption','proposal','clarification','context','user constraint'}:
            continue  # Provenance labels are not evidence-ID claims.
        parts = re.split(r'\s*[,;]\s*', match[1].strip())
        if all(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}', part) for part in parts):
            for part in parts:
                yield part, match[2]


def requirements(markdown):
    result = []
    for line in markdown.splitlines():
        match = re.match(r'^\s*(?:[-*]\s*)?(?:\*\*)?(R(?:EQ)?[- ]?\d+)\b', line)
        if match:
            result.append((match[1], line.strip()))
    return result


def without_server_register(markdown):
    # A revision may copy the reserved heading from its input. Exclude that
    # register consistently for both arms; keep raw artifacts unchanged.
    return re.sub(r'^## Source links \(server-attached\)\s*\n.*?(?=^## |\Z)', '',
                  markdown, flags=re.M | re.S).rstrip()


def acceptance_records(markdown):
    """Parse explicit AC-numbered blocks in the acceptance section only."""
    section = re.search(r'^##\s+Acceptance criteria\s*\n(.*?)(?=^##\s|\Z)', markdown, re.I | re.M | re.S)
    if not section:
        return []
    starts = list(re.finditer(r'^\s*(?:[-*]\s*)?(?:\*\*)?(AC\d+)\b', section[1], re.M | re.I))
    records = []
    for i, match in enumerate(starts):
        end = starts[i + 1].start() if i + 1 < len(starts) else len(section[1])
        block = section[1][match.start():end].strip()
        ids = sorted(set(re.findall(r'\bR(?:EQ)?[- ]?\d+\b', block)))
        testable_shape = all(re.search(r'\b'+word+r'\b', block, re.I) for word in ('given','when','then'))
        records.append({'id':match[1].upper(),'requirement_ids':ids,'text':block,'given_when_then':testable_shape})
    return records
