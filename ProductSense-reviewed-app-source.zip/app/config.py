import os
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / '.env')
# Never allow ambient LangSmith tracing to send uploaded feedback to a paid/external service.
os.environ['LANGSMITH_TRACING'] = 'false'
os.environ['LANGCHAIN_TRACING_V2'] = 'false'
# Explicitly exclude ambient enterprise/Vertex routing from this Developer API app.
os.environ['GOOGLE_GENAI_USE_VERTEXAI'] = 'false'
os.environ['GOOGLE_GENAI_USE_ENTERPRISE'] = 'false'
MAX_ROWS = 30
MAX_FILE_BYTES = 100_000
MAX_TEXT = 1200
MAX_CALLS = 6
MAX_DAILY_CALLS = 20
MAX_INPUT_CHARS = 60_000
MAX_OUTPUT_TOKENS = 6000
MAX_PRD_CHARS = 40_000
FREE_MODELS = {'gemini-3.5-flash-lite', 'gemini-3.8-flash'}

def provider_settings():
    return {
        'api_key': os.getenv('GEMINI_API_KEY', ''),
        'model': os.getenv('GEMINI_MODEL', 'gemini-3.5-flash-lite'),
        'confirmed': os.getenv('GEMINI_FREE_TIER_CONFIRMED', '').lower() == 'true',
        'public_data': os.getenv('GEMINI_PUBLIC_DATA_CONFIRMED', '').lower() == 'true',
    }

def gemini_ready():
    s = provider_settings()
    return bool(s['api_key'] and s['confirmed'] and s['public_data'] and s['model'] in FREE_MODELS)
