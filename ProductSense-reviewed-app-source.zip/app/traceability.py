"""Requirement-to-evidence traceability and version comparison.

Everything here is deterministic and offline. Principles:
* Observed facts (supplied feedback) and proposals/assumptions are kept separate.
* Matches are LEXICAL aids. A cited ID or a word overlap never proves that the source
  entails the requirement; the UI must say so. No accuracy percentage is produced:
  only counts and candidate flags for human inspection.
* Nothing is rewritten; the matrix is a read-only view over saved Markdown + feedback.
"""
import re
from difflib import SequenceMatcher
from .evidence import references, requirements as requirement_records, acceptance_records, without_server_register

LABELS = {
    'assumption': 'assumption', 'proposal': 'proposal', 'proposed': 'proposal',
    'user constraint': 'user_constraint', 'user-supplied': 'user_constraint', 'clarification': 'clarification',
}
STOP = set('the and for with that this from user users can shall must should when then given will are not has have into its any all each only'.split())
NUMBER = re.compile(r'(?<![\w.])(\d+(?:[.,]\d+)?)\s*(%|ms|milliseconds?|seconds?|secs?|minutes?|mins?|hours?|days?|weeks?|months?|mb|gb|kb|px|users?|customers?|requests?|items?)?\b', re.I)
VAGUE = re.compile(r'\b(fast|quickly|reasonable|acceptable|user.friendly|intuitive|seamless|robust|easy to use|as needed|appropriate|etc\.?)\b', re.I)
UNCERTAIN = re.compile(r'\b(unknown|unverified|not verified|not established|to be (?:agreed|decided|defined)|open question|undecided|unmeasured)\b', re.I)
CURRENT = re.compile(r'\b(currently|at present|today|now)\b[^.]{0,60}\b(missing|unavailable|unsupported|unable|broken|fails?|cannot|can.t|does not|lacks?)\b', re.I)


def content_words(text):
    return {w for w in re.findall(r'[a-z]{3,}', text.lower())} - STOP


def lexical_overlap(left, right):
    a, b = content_words(left), content_words(right)
    return round(len(a & b) / len(a | b), 3) if a and b else 0.0


LABEL_PHRASES = (('proposal', 'proposal'), ('assumption', 'assumption'), ('user constraint', 'user_constraint'),
                 ('user-supplied', 'user_constraint'), ('clarification', 'clarification'))
ATTRIBUTION = re.compile(r'\b(reported|reports?|historical(?:ly)?|according|whether|users? (?:say|said|reported))\b', re.I)


def provenance_labels(line):
    """Explicit provenance markers only: a bracketed [Label], a 'Provenance:' clause, or a 'Label:' prefix.
    Ordinary prose such as 'validate proposed expirations' is NOT a label (amendment A2)."""
    found = set()
    for m in re.finditer(r'\[([^\]\n]+)\]', line):
        key = m[1].strip().lower()
        if key in LABELS:
            found.add(LABELS[key])
    clause = re.search(r'provenance\s*:\s*([^\n]*)', line, re.I)
    for phrase, label in LABEL_PHRASES:
        if clause and re.search(r'\b' + phrase + r'\b', clause[1], re.I):
            found.add(label)
        if re.search(r'(?:^|[\s(\u2014-])' + phrase + r'\s*:', line, re.I):
            found.add(label)
    return sorted(found)


def unattributed_current_claim(line):
    """A current-status claim with no attribution word in the SAME sentence (amendment A2; was: anywhere on the line)."""
    return any(CURRENT.search(sent) and not ATTRIBUTION.search(sent) for sent in re.split(r'(?<=[.!?])\s+', line))


def _strip_ids(line):
    line = re.sub(r'\[[^\]\n]+\](?:\([^)\n]+\))?', ' ', line)
    return re.sub(r'\b(?:R(?:EQ)?[- ]?\d+|AC\d+|OP-\d+)\b', ' ', line, flags=re.I)


def number_in(text, digits):
    """Token-boundary match: '95' is not found inside '1995' or '3.95'; '30' is not found inside '30,000'."""
    return re.search(r'(?<![\d.,])' + re.escape(digits) + r'(?!\d|[.,]\d)', text) is not None


def numeric_tokens(line):
    return [m[0].strip() for m in NUMBER.finditer(_strip_ids(line))]


def _section(markdown, name):
    m = re.search(r'^##\s+' + re.escape(name) + r'\s*\n(.*?)(?=^##\s|\Z)', markdown, re.I | re.M | re.S)
    return m[1] if m else ''


def _bullets(text):
    return [re.sub(r'^\s*(?:[-*]|\d+[.)])\s*', '', l).strip() for l in text.splitlines() if re.match(r'^\s*(?:[-*]|\d+[.)])\s+', l)]


def requirement_matrix(markdown, feedback, extra_texts=()):
    """Map each numbered requirement to evidence, provenance label, acceptance links and review flags."""
    body = without_server_register(markdown or '')
    known = {r['id']: r for r in feedback}
    extra = ' '.join(extra_texts)
    criteria = acceptance_records(body)
    rows = []
    for rid, line in requirement_records(body):
        cites = []
        for cid, url in references(line):
            if re.fullmatch(r'R(?:EQ)?[- ]?\d+', cid) and cid not in known:
                continue  # internal requirement cross-reference, not evidence
            row = known.get(cid)
            source_text = ''
            if row:
                source_text = str(row.get('source_excerpt') or row.get('text') or '')
            cites.append({
                'id': cid, 'known': row is not None,
                'excerpt': source_text[:300],
                'excerpt_is_supplied_source': bool(row and row.get('source_excerpt')),
                'source_url': (row or {}).get('source_url', ''),
                'source_status': (row or {}).get('source_status') or (row or {}).get('source_state') or 'Unknown',
                'lexical_overlap': lexical_overlap(_strip_ids(line), source_text) if row else None,
                'note': 'Lexical overlap only; does not establish that the source supports the requirement.',
            })
        labels = provenance_labels(line)
        valid = [c for c in cites if c['known']]
        flags = []
        def flag(code, severity, message):
            flags.append({'code': code, 'severity': severity, 'message': message})
        for c in cites:
            if not c['known']:
                flag('unknown_evidence_id', 'error', f"Cited ID {c['id']} is not in the supplied feedback.")
        if not valid and not labels:
            flag('no_provenance', 'error', 'No valid evidence ID and no Proposal/Assumption/User constraint label.')
        if valid and all((c['lexical_overlap'] or 0) < 0.04 for c in valid):
            flag('weak_lexical_link', 'info', 'Cited sources share almost no vocabulary with this requirement; candidate for human relevance check (not a conclusion).')
        linked = [ac for ac in criteria if rid in ac['requirement_ids']]
        if not linked:
            flag('no_acceptance', 'error', 'No AC-numbered criterion links to this requirement.')
        elif not any(ac['given_when_then'] for ac in linked):
            flag('acceptance_not_gwt', 'warning', 'Linked acceptance criteria lack Given/When/Then shape.')
        source_blob = ' '.join(str(known[c['id']].get('text', '')) + ' ' + str(known[c['id']].get('source_excerpt', '')) for c in valid) + ' ' + extra
        for tok in numeric_tokens(line):
            digits = re.match(r'[\d.,]+', tok)[0]
            if not number_in(source_blob, digits) and not UNCERTAIN.search(line):
                flag('numeric_not_in_evidence', 'warning', f'Number "{tok}" does not occur in cited evidence or user-supplied context; an invented target must be authorised or marked undecided.')
        if VAGUE.search(line) and not UNCERTAIN.search(line):
            flag('vague_language', 'warning', 'Contains vague wording; define an observable outcome or mark the measure as undecided.')
        if unattributed_current_claim(line):
            flag('unattributed_current_claim', 'warning', 'Asserts current product behaviour without attributing it to a dated source report.')
        # Observed-vs-proposed separation: requirements are proposals by nature; mixing a citation with 'proposal' is fine,
        # but a bare citation never turns a proposal into an observed fact.
        rows.append({
            'id': rid, 'text': re.sub(r'^\s*(?:[-*]|\d+[.)])\s*', '', line), 'evidence': cites, 'provenance_labels': labels,
            'provenance': 'evidence' if valid else (labels[0] if labels else 'none'),
            'acceptance': [{'id': ac['id'], 'given_when_then': ac['given_when_then']} for ac in linked],
            'flags': flags,
        })
    assumptions = _bullets(_section(body, 'Assumptions'))
    open_q = _bullets(_section(body, 'Open questions'))
    ids = [r['id'] for r in rows]
    summary = {
        'requirements': len(rows),
        'with_valid_evidence_id': sum(1 for r in rows if r['provenance'] == 'evidence'),
        'labelled_proposal_assumption_or_constraint_only': sum(1 for r in rows if r['provenance'] not in ('evidence', 'none')),
        'without_provenance': sum(1 for r in rows if r['provenance'] == 'none'),
        'without_linked_acceptance': sum(1 for r in rows if any(f['code'] == 'no_acceptance' for f in r['flags'])),
        'with_flags': sum(1 for r in rows if r['flags']),
        'duplicate_requirement_ids': sorted({i for i in ids if ids.count(i) > 1}),
        'assumptions_listed': len(assumptions), 'open_questions_listed': len(open_q),
        'notice': 'Counts for inspection. Cited IDs and lexical overlap do not prove semantic support; no accuracy score is defined.',
    }
    unused = sorted(set(known) - {c['id'] for r in rows for c in r['evidence']})
    return {'requirements': rows, 'assumptions': assumptions, 'open_questions': open_q,
            'evidence_not_cited_by_any_requirement': unused, 'summary': summary}


def _norm(text):
    return ' '.join(re.sub(r'\[[^\]\n]+\](?:\([^)\n]+\))?', ' ', text).lower().split())


def compare_versions(old_md, new_md, feedback):
    """Requirement-level comparison of two PRD versions with affected evidence links."""
    a = {r['id']: r for r in requirement_matrix(old_md, feedback)['requirements']}
    b = {r['id']: r for r in requirement_matrix(new_md, feedback)['requirements']}
    added, removed, changed, unchanged = [], [], [], []
    for rid, new in b.items():
        old = a.get(rid)
        if old is None:
            added.append(rid); continue
        ev_old, ev_new = {c['id'] for c in old['evidence']}, {c['id'] for c in new['evidence']}
        ac_old, ac_new = {x['id'] for x in old['acceptance']}, {x['id'] for x in new['acceptance']}
        if _norm(old['text']) != _norm(new['text']) or ev_old != ev_new or ac_old != ac_new:
            changed.append({'id': rid, 'text_changed': _norm(old['text']) != _norm(new['text']),
                            'before': old['text'], 'after': new['text'],
                            'evidence_added': sorted(ev_new - ev_old), 'evidence_removed': sorted(ev_old - ev_new),
                            'acceptance_added': sorted(ac_new - ac_old), 'acceptance_removed': sorted(ac_old - ac_new),
                            'new_flags': sorted({f['code'] for f in new['flags']} - {f['code'] for f in old['flags']})})
        else:
            unchanged.append(rid)
    removed = [rid for rid in a if rid not in b]
    renumbered = []
    for rid_new in list(added):
        for rid_old in list(removed):
            if SequenceMatcher(None, _norm(a[rid_old]['text']), _norm(b[rid_new]['text'])).ratio() >= .85:
                renumbered.append({'from': rid_old, 'to': rid_new}); added.remove(rid_new); removed.remove(rid_old); break
    return {'added': added, 'removed': removed, 'changed': changed, 'unchanged': unchanged,
            'possible_renumbering': renumbered,
            'note': 'Stable requirement IDs are compared by ID; text similarity >= .85 suggests renumbering. Review changes manually; scope sections need renewed approval.'}


def install_traceability(app, store, get):
    """Read-only routes; ownership is enforced by the /api/sessions/{sid}/... visitor middleware."""
    from fastapi import HTTPException

    @app.get('/api/sessions/{sid}/traceability')
    def traceability(sid: str):
        current = get(sid)
        if not current.get('prd_markdown'):
            raise HTTPException(409, 'Approve an opportunity and generate a PRD first.')
        context = current.get('context') or {}
        extra = [str(v) for v in context.values() if isinstance(v, str)] + [current.get('corrections') or '']
        return requirement_matrix(current['prd_markdown'], current['feedback'], extra)

    @app.get('/api/sessions/{sid}/versions/compare')
    def versions_compare(sid: str, a: int | None = None, b: int | None = None):
        get(sid)
        versions = store.versions(sid)
        if len(versions) < 2 and (a is None or b is None):
            return {'available': False, 'reason': 'At least two saved versions are needed to compare.'}
        byid = {v['id']: v for v in versions}
        try:
            old = byid[a] if a is not None else versions[-2]
            new = byid[b] if b is not None else versions[-1]
        except KeyError:
            raise HTTPException(404, 'Version not found.') from None
        current = get(sid)
        result = compare_versions(old['markdown'], new['markdown'], current['feedback'])
        return {**result, 'available': True, 'from': {'id': old['id'], 'origin': old['origin'], 'created_utc': old['created_utc']},
                'to': {'id': new['id'], 'origin': new['origin'], 'created_utc': new['created_utc']}}


def csv_safe(value):
    """Neutralise spreadsheet formula injection: prefix cells that begin with = + - @ TAB or CR with an apostrophe."""
    text = '' if value is None else str(value)
    return "'" + text if text[:1] in ('=', '+', '-', '@', '\t', '\r') else text


MATRIX_COLUMNS = ['requirement_id', 'requirement_text', 'provenance', 'labels', 'evidence_ids', 'unknown_evidence_ids',
                  'acceptance_ids', 'flags']


def matrix_csv(matrix):
    import csv, io
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator='\r\n')
    w.writerow(MATRIX_COLUMNS)
    for r in matrix['requirements']:
        w.writerow([csv_safe(x) for x in (
            r['id'], r['text'], r['provenance'], ';'.join(r['provenance_labels']),
            ';'.join(c['id'] for c in r['evidence'] if c['known']), ';'.join(c['id'] for c in r['evidence'] if not c['known']),
            ';'.join(a['id'] for a in r['acceptance']), ';'.join(f['code'] for f in r['flags']))])
    return buf.getvalue()


def install_traceability_csv(app, get):
    from fastapi import HTTPException
    from fastapi.responses import Response

    @app.get('/api/sessions/{sid}/traceability.csv')
    def traceability_csv(sid: str):
        current = get(sid)
        if not current.get('prd_markdown'):
            raise HTTPException(409, 'Approve an opportunity and generate a PRD first.')
        context = current.get('context') or {}
        extra = [str(v) for v in context.values() if isinstance(v, str)] + [current.get('corrections') or '']
        body = matrix_csv(requirement_matrix(current['prd_markdown'], current['feedback'], extra))
        return Response(body, media_type='text/csv; charset=utf-8',
                        headers={'Content-Disposition': 'attachment; filename="requirement-evidence-matrix.csv"', 'X-Content-Type-Options': 'nosniff'})


def install_ledger_route(app, get):
    from fastapi import HTTPException
    from .evidence_ledger import build_ledger

    @app.get('/api/sessions/{sid}/evidence-ledger')
    def evidence_ledger(sid: str, opportunity_id: str | None = None):
        s = get(sid)
        selected = next((o for o in s.get('opportunities', []) if o['id'] == (opportunity_id or s.get('selected_opportunity_id'))), None)
        if not selected:
            raise HTTPException(409, 'Analyze feedback and select an opportunity first.')
        payload = {'context': s.get('context') or {}, 'opportunity': selected, 'corrections': s.get('corrections', ''),
                   'clarification': s.get('clarification', 'Unknown'),
                   'feedback': [r for r in s['feedback'] if r['id'] in selected['evidence_ids']]}
        return build_ledger(payload)
