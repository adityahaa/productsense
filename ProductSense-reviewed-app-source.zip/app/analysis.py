"""Transparent local evidence aids. Similarity and support labels are not truth scores."""
import re
from difflib import SequenceMatcher
from collections import Counter


def words(text):
    return set(re.findall(r'[a-z]{3,}',text.lower()))-set('the and for with that this from user users'.split())


def duplicates(rows):
    pairs=[]
    for i,a in enumerate(rows):
        for b in rows[i+1:]:
            left=' '.join(a['text'].lower().split());right=' '.join(b['text'].lower().split())
            overlap=len(words(left)&words(right))/max(1,len(words(left)|words(right)))
            if SequenceMatcher(None,left,right).ratio()>=.82 or overlap>=.72:
                pairs.append({'ids':[a['id'],b['id']],'reason':'High lexical similarity; review possible duplicate. No row removed; no semantic equivalence established.'})
    return pairs


def opportunity_details(group,rows,context):
    byid={r['id']:r for r in rows}; selected=[byid[i] for i in group['evidence_ids']]
    customers={r['customer_id'] for r in selected if r.get('customer_id')}
    relations=group.get('relations',[])
    evidence=[]
    for row in selected:
        quote=row.get('source_quote') or row.get('source_excerpt') or row['text']
        evidence.append({'id':row['id'],'quote':quote,'quote_matches_supplied_source':quote in row['text'] or quote==row.get('source_excerpt'),
            'quote_basis':'supplied excerpt' if row.get('source_excerpt') else 'supplied feedback text; may paraphrase original',
            'source_url':row.get('source_url',''),'date':row.get('source_date') or row.get('source_created_at') or 'Unknown',
            'status':row.get('source_status') or row.get('source_state') or 'Unknown',
            'semantic_support':'Unassessed; matching text does not establish support for this opportunity.'})
    conflicts=[r for r in relations if r['kind']=='conflict']
    missing=['Current product behaviour and current demand are unverified.','Effort and business impact are unestimated.']
    if any(not r.get('customer_id') for r in selected): missing.append('Customer identifiers are incomplete; rows are not unique customers.')
    if any(e['date']=='Unknown' or e['status']=='Unknown' for e in evidence):missing.append('Some source dates or statuses are missing.')
    alignment=sorted(words(context['goals']) & words(' '.join(r['text'] for r in selected)))
    recommendation=group.get('recommendation') or 'Investigate'
    reason=group.get('recommendation_reason') or ('Conflicting requests need a scoped product decision. ' if conflicts else '')+'Current need, feasibility and acceptance fixtures require validation before a build commitment.'
    return {'row_count':len(selected),'identified_customers':len(customers) if customers else None,
        'rows_with_customer_id':sum(bool(r.get('customer_id')) for r in selected),'evidence':evidence,
        'relations':relations,'missing_information':missing,'recommendation':recommendation,
        'recommendation_reason':reason,'goal_keywords':alignment,
        'clarification_questions':['What happens in the current product? Unknown is allowed.','What belongs in/out of this scope?','Which fixture and observable result will define acceptance?'],
        'validation_plan':['Inspect current behaviour and source resolution.','Ask the source owners about the task and remaining workaround.','Agree a narrow fixture, scope and acceptance outcome before engineering estimation.']}


def prioritize_groups(groups,rows,context):
    result=[]; byid={r['id']:r for r in rows}; goals=words(context['goals'])
    for i,group in enumerate(groups,1):
        ids=group['evidence_ids']; overlap=len(goals & words(' '.join(byid[r]['text'] for r in ids)))/max(1,len(goals));share=len(ids)/len(rows)
        result.append({**group,'id':group.get('id') or f'OP-{i}','score':round(70*share+30*overlap),
            'confidence':'Limited — reviewable sample only','rationale':f'{len(ids)} of {len(rows)} rows. Score = 70 × sample share + 30 × goal-keyword overlap; no effort or impact estimate.',
            'score_components':{'sample_share':share,'goal_keyword_overlap':overlap},
            'details':opportunity_details(group,rows,context)})
    return sorted(result,key=lambda o:(-o['score'],o['id']))


def scope_checks(markdown,scope):
    """Literal conflict candidates, explicitly not a semantic contradiction oracle."""
    issues=[]
    for phrase in re.split(r'[;\n]',scope.get('excluded','')):
        phrase=phrase.strip()
        if len(phrase)<3:continue
        for line in markdown.splitlines():
            if re.match(r'^\s*[-*]?\s*R\d+\b',line) and phrase.lower() in line.lower() and not re.search(r'\b(exclude|excluded|not|out of scope|without)\b',line,re.I):
                issues.append({'severity':'warning','message':f'Potential scope contradiction: requirement mentions excluded phrase "{phrase}". Literal match only; review context.'})
    return issues
