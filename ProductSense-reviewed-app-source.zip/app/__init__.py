"""ProductSense local application."""
