import csv
import io
import re
from datetime import date
from urllib.parse import urlsplit
from .config import MAX_ROWS, MAX_FILE_BYTES, MAX_TEXT

def safe_url(value: str) -> bool:
    try:
        p = urlsplit(value)
        return p.scheme in ('http', 'https') and bool(p.hostname) and not p.username and not p.password and not re.search(r'[\s<>"\[\]()\\]', value)
    except ValueError:
        return False

def parse_csv(content: bytes) -> list[dict]:
    if not content or len(content) > MAX_FILE_BYTES:
        raise ValueError(f'CSV must be non-empty and at most {MAX_FILE_BYTES:,} bytes.')
    try:
        text = content.decode('utf-8-sig')
    except UnicodeDecodeError:
        raise ValueError('Save your CSV as UTF-8 (CSV UTF-8 in Excel).') from None
    if '\x00' in text:
        raise ValueError('CSV contains a null character.')
    reader = csv.DictReader(io.StringIO(text, newline=''), strict=True)
    if not reader.fieldnames or 'text' not in reader.fieldnames:
        raise ValueError('CSV needs a text column. Optional columns: id, source_url.')
    if len(set(reader.fieldnames)) != len(reader.fieldnames):
        raise ValueError('CSV contains duplicate column names.')
    rows, ids, seen = [], set(), set()
    try:
        for n, row in enumerate(reader, 1):
            if n > MAX_ROWS:
                raise ValueError(f'Start with at most {MAX_ROWS} feedback rows; split larger CSVs.')
            if None in row or any(v is None for v in row.values()):
                raise ValueError(f'Row {n}: column count does not match the header.')
            body = row['text'].strip()
            rid = row.get('id', '').strip() or f'FB-{n:03}'
            url = row.get('source_url', '').strip()
            if not body or len(body) > MAX_TEXT:
                raise ValueError(f'Row {n}: text must contain 1–{MAX_TEXT} characters.')
            if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}', rid) or rid in ids:
                raise ValueError(f'Row {n}: id must be unique, using letters, numbers, underscores or hyphens.')
            normalized = ' '.join(body.lower().split())
            if normalized in seen:
                raise ValueError(f'Row {n}: duplicate feedback text. Remove duplicates to avoid inflated counts.')
            if url and (len(url) > 1000 or not safe_url(url)):
                raise ValueError(f'Row {n}: source_url must be a safe http or https URL.')
            ids.add(rid)
            seen.add(normalized)
            item = {'id': rid, 'text': body, 'source_url': url, 'source_kind': 'uploaded_feedback'}
            for field, limit in {'source_date':32,'source_status':80,'customer_id':80,'source_quote':1200}.items():
                value = row.get(field, '').strip()
                if len(value)>limit:
                    raise ValueError(f'Row {n}: {field} is too long (maximum {limit}).')
                if value:
                    if field=='source_date':
                        try: date.fromisoformat(value)
                        except ValueError: raise ValueError(f'Row {n}: source_date must be YYYY-MM-DD.') from None
                    if field=='source_quote' and value not in body:
                        raise ValueError(f'Row {n}: source_quote must exactly match part of the supplied text.')
                    item[field]=value
            rows.append(item)
    except csv.Error:
        raise ValueError('Malformed CSV quoting. Export again as CSV UTF-8.') from None
    if not rows:
        raise ValueError('CSV must include at least one feedback row.')
    return rows
