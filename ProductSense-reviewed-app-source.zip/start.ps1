param([int]$Port = 8001)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) { Write-Error 'Run: py -3.11 launch.py setup'; exit 1 }
& '.\.venv\Scripts\python.exe' launch.py start --port $Port
exit $LASTEXITCODE
