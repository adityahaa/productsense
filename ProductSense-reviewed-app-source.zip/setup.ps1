$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (Test-Path -LiteralPath '.venv\Scripts\python.exe') { & '.\.venv\Scripts\python.exe' launch.py setup }
elseif (Get-Command py -ErrorAction SilentlyContinue) { & py -3.11 launch.py setup }
else { Write-Error 'Install Python 3.11 or 3.12 from python.org. Then run: python launch.py setup'; exit 1 }
exit $LASTEXITCODE
