"""Build CDN assets only; never opens a database or imports application code."""
from pathlib import Path
import shutil
ROOT=Path(__file__).resolve().parents[1]
def main():
    target=ROOT/'public'
    target.mkdir(exist_ok=True)
    shutil.copy2(ROOT/'static/index.html',target/'index.html')
    shutil.copytree(ROOT/'static',target/'static',dirs_exist_ok=True)
    print('CDN shell and assets prepared; no database or API calls.')
if __name__=='__main__':main()
