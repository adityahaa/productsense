"""Windows-friendly setup and launch without shell activation or global policy changes."""
import argparse
import importlib.util
import socket
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['setup','start','review','check']);p.add_argument('--port',type=int);a=p.parse_args()
 if sys.version_info[:2] not in ((3,11),(3,12)):raise SystemExit('Use Python 3.11 or 3.12. Try: py -3.11 launch.py '+a.command)
 python=ROOT/'.venv'/('Scripts/python.exe' if sys.platform=='win32' else 'bin/python')
 if a.command=='setup':
  if not python.exists():subprocess.run([sys.executable,'-m','venv',str(ROOT/'.venv')],check=True)
  else:print('Preserving existing .venv, .env and runtime data.')
  result=subprocess.run([str(python),'-m','pip','install','-r',str(ROOT/'requirements.lock.txt')],cwd=ROOT)
  if result.returncode:raise SystemExit('Dependency install failed. Check internet access and rerun setup; no private files were replaced.')
  print('Setup complete. No key needed for demo. Run: py -3.11 launch.py start');return
 if not python.exists():raise SystemExit('Environment missing. First run: py -3.11 launch.py setup')
 check=subprocess.run([str(python),'-c','import fastapi, uvicorn, langgraph, docx'],capture_output=True)
 if check.returncode:raise SystemExit('Dependencies unavailable. Run: py -3.11 launch.py setup')
 if a.command=='check':print('Python environment and core dependencies ready. No API calls made.');return
 port=a.port or (8010 if a.command=='review' else 8001)
 if not 1024<=port<=65535:raise SystemExit('Choose an available port between 1024 and 65535.')
 with socket.socket() as sock:
  try:sock.bind(('127.0.0.1',port))
  except OSError:raise SystemExit(f'Port {port} is already in use. Existing app may be at http://127.0.0.1:{port}. Stop its terminal with Ctrl+C, or use --port {port+1}.')
 target='evaluation.author_review:create_app' if a.command=='review' else 'app.main:app'
 print(f'Open http://127.0.0.1:{port} — keep this window open. Ctrl+C stops; repeat this command to restart.',flush=True)
 command=[str(python),'-m','uvicorn',target,'--host','127.0.0.1','--port',str(port),'--no-access-log']
 if a.command=='review':command.append('--factory')
 try:raise SystemExit(subprocess.call(command,cwd=ROOT))
 except KeyboardInterrupt:print('\nStopped. Saved work remains local; interrupted provider usage may be unknown.')
if __name__=='__main__':main()
