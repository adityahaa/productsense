"""Deterministic (mock-free, offline) tests for requirement-evidence traceability."""
from fastapi.testclient import TestClient
from app.main import create_app
from app.traceability import requirement_matrix, compare_versions, numeric_tokens, provenance_labels
from conftest import complete_demo

FEEDBACK = [
    {'id': 'F1', 'text': 'Export to PDF fails for large boards after 30 seconds.', 'source_excerpt': 'Export to PDF fails for large boards', 'source_url': 'https://example.test/1'},
    {'id': 'F2', 'text': 'Please add dark mode for the toolbar.', 'source_url': 'https://example.test/2'},
    {'id': 'F3', 'text': 'Unrelated remark about billing invoices.'},
]
PRD = """## Requirements
- R1: The editor shall export large boards to PDF. [F1]
- R2: Export shall complete within 5 seconds. [Proposal]
- R3: The toolbar shall support dark mode. [F9]
- R4: The product is currently unable to export PDF and is user-friendly.
## Acceptance criteria
- AC1 (R1): Given a large board, when exporting, then a PDF opens.
- AC2 (R2): Export should be quick.
## Assumptions
- Boards are under 100 MB.
## Open questions
- Which page sizes are required?
"""


def flags(row):
    return {f['code'] for f in row['flags']}


def test_matrix_flags_and_counts():
    m = requirement_matrix(PRD, FEEDBACK)
    rows = {r['id']: r for r in m['requirements']}
    assert not rows['R1']['text'].startswith(('-', '*')) and rows['R1']['provenance'] == 'evidence' and flags(rows['R1']) == set()
    assert 'numeric_not_in_evidence' in flags(rows['R2']) and rows['R2']['provenance'] == 'proposal'
    assert 'acceptance_not_gwt' in flags(rows['R2'])
    assert 'unknown_evidence_id' in flags(rows['R3']) and 'no_provenance' in flags(rows['R3'])
    assert {'no_acceptance', 'vague_language', 'unattributed_current_claim'} <= flags(rows['R4'])
    s = m['summary']
    assert (s['requirements'], s['with_valid_evidence_id'], s['without_provenance']) == (4, 1, 2)
    assert s['assumptions_listed'] == 1 and s['open_questions_listed'] == 1
    assert 'accuracy' not in ' '.join(k for k in s if k != 'notice')
    assert m['evidence_not_cited_by_any_requirement'] == ['F2', 'F3']


def test_number_supported_by_evidence_or_user_context_is_not_flagged():
    md = '## Requirements\n- R1: Export shall retry after 30 seconds. [F1]\n- R2: Boards up to 50 pages shall export. [Assumption]\n## Acceptance criteria\n- AC1 (R1, R2): Given a board, when exported, then a file opens.\n'
    rows = {r['id']: r for r in requirement_matrix(md, FEEDBACK)['requirements']}
    assert 'numeric_not_in_evidence' not in flags(rows['R1'])      # "30" appears in F1
    assert 'numeric_not_in_evidence' in flags(rows['R2'])
    rows = {r['id']: r for r in requirement_matrix(md, FEEDBACK, ['Limit is 50 pages by request'])['requirements']}
    assert 'numeric_not_in_evidence' not in flags(rows['R2'])


def test_requirement_ids_not_counted_as_numbers_and_labels_detected():
    assert numeric_tokens('R12 shall satisfy AC3 [F1] and [OP-4]') == []
    assert provenance_labels('R1 [Assumption] and a proposed change') == ['assumption']      # prose word is not a label (A2)
    assert provenance_labels('R2. Do X. Provenance: User constraint [goals].') == ['user_constraint'] and provenance_labels('R3 Proposal: cancel exports') == ['proposal']
    assert provenance_labels('R4 validate proposed expirations') == [] and provenance_labels('R5. Provenance: Evidence-informed.') == []


def test_empty_and_missing_sections_are_safe():
    assert requirement_matrix('', FEEDBACK)['summary']['requirements'] == 0
    assert requirement_matrix('## Problem statement\nText', [])['requirements'] == []


def test_server_register_is_excluded():
    md = PRD + '\n## Source links (server-attached)\n- R9: fake [F1]\n'
    assert len(requirement_matrix(md, FEEDBACK)['requirements']) == 4


def test_compare_versions_added_removed_changed_renumbered():
    new = PRD.replace('R1: The editor shall export large boards to PDF. [F1]', 'R1: The editor shall export large boards to PDF and SVG. [F1, F2]')
    new = new.replace('- R3: The toolbar shall support dark mode. [F9]\n', '')
    new += '- R7: Export shall complete within 5 seconds. [Proposal]\n'   # same text as R2 -> renumbering candidate
    new = new.replace('- R2: Export shall complete within 5 seconds. [Proposal]\n', '')
    c = compare_versions(PRD, new, FEEDBACK)
    assert 'R3' in c['removed']
    assert {'from': 'R2', 'to': 'R7'} in c['possible_renumbering'] and 'R7' not in c['added']
    ch = {x['id']: x for x in c['changed']}
    assert ch['R1']['evidence_added'] == ['F2'] and ch['R1']['text_changed']
    assert compare_versions(PRD, PRD, FEEDBACK)['changed'] == []


def test_api_traceability_and_version_compare_with_ownership(tmp_path):
    app = create_app(tmp_path)
    with TestClient(app) as owner, TestClient(app) as stranger:
        s = complete_demo(owner)
        base = '/api/sessions/' + s['id']
        m = owner.get(base + '/traceability')
        assert m.status_code == 200 and m.json()['summary']['requirements'] >= 1
        first = owner.get(base + '/versions/compare')
        assert first.status_code == 200 and first.json()['available'] is False          # only one version so far
        edited = s['prd_markdown'] + '\n\nAdded note for comparison.\n'
        assert owner.patch(base + '/prd', json={'markdown': edited}).status_code == 200
        cmp_ = owner.get(base + '/versions/compare')
        assert cmp_.status_code == 200 and cmp_.json()['available'] is True and cmp_.json()['to']['origin'] == 'manual'
        assert owner.get(base + '/versions/compare?a=999999&b=1').status_code == 404
        for tail in ('/traceability', '/versions/compare'):
            assert stranger.get(base + tail).status_code == 404


def test_number_matching_uses_token_boundaries_not_substrings():
    from app.traceability import number_in
    assert number_in('fails after 30 seconds', '30') and number_in('limit 3.5 MB', '3.5')
    assert not number_in('released in 1995', '95') and not number_in('about 3.95 units', '95')
    assert not number_in('30,000 users', '30') and not number_in('v2024', '20')
    md = '## Requirements\n- R1: Export shall finish for 95% of boards. [F1]\n## Acceptance criteria\n- AC1 (R1): Given a board, when exported, then a file opens.\n'
    rows = [{'id': 'F1', 'text': 'This was already broken in 1995 and 2005.'}]
    assert 'numeric_not_in_evidence' in {f['code'] for r in requirement_matrix(md, rows)['requirements'] for f in r['flags']}


def test_current_claim_attribution_must_be_in_same_sentence():
    from app.traceability import unattributed_current_claim as u
    assert u('The product currently cannot export PDFs.') is True
    assert u('Reports indicate the product currently cannot export PDFs.') is False
    assert u('Historical reports mention export. The product currently cannot export PDFs.') is True
    assert u('The tracker is historical. It says nothing now.') is False
