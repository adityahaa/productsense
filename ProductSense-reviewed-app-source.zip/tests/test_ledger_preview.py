from fastapi.testclient import TestClient
from app.main import create_app
from conftest import settled

def test_selected_ledger_is_available_before_approval_without_changing_scope(tmp_path):
    with TestClient(create_app(tmp_path)) as owner, TestClient(create_app(tmp_path / 'other')) as other:
        s=owner.post('/api/sessions/demo',json={'mode':'demo'}).json()
        sid=s['id'];base='/api/sessions/'+sid
        owner.post(base+'/analyze');s=settled(owner,sid)
        choice=s['opportunities'][0]['id']
        r=owner.get(base+'/evidence-ledger',params={'opportunity_id':choice})
        assert r.status_code==200 and r.json()['observed_reports']
        after=owner.get(base).json()
        assert after['status']=='awaiting_approval' and not after['selected_opportunity_id'] and not after['prd_markdown']
        assert owner.get(base+'/evidence-ledger?opportunity_id=unknown').status_code==409
        assert other.get(base+'/evidence-ledger',params={'opportunity_id':choice}).status_code==404
